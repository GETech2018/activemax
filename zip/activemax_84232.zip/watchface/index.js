﻿    /*
    ** Watch_Face_Editor tool v 18.0
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_month = ''
        let normal_bio_charge_text_text_img = ''
        let normal_bio_charge_text_separator_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_battery_image_progress_img_level = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_month = ''
        let idle_bio_charge_text_text_img = ''
        let idle_bio_charge_text_separator_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_date_day_separator_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_step_current_text_img = ''
        let idle_step_current_separator_img = ''
        let idle_calorie_current_text_img = ''
        let idle_calorie_current_separator_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_battery_image_progress_img_level = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let Button_10 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Background.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 294,
              month_startY: 89,
              month_sc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              month_tc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              month_en_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              month_zero: 0,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 179,
              y: 350,
              font_array: ["bottom_0.png","bottom_1.png","bottom_2.png","bottom_3.png","bottom_4.png","bottom_5.png","bottom_6.png","bottom_7.png","bottom_8.png","bottom_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 122,
              y: 350,
              src: 'label_hc.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 136,
              y: 38,
              image_array: ["weather_icon_00.png","weather_icon_01.png","weather_icon_02.png","weather_icon_03.png","weather_icon_04.png","weather_icon_05.png","weather_icon_06.png","weather_icon_07.png","weather_icon_08.png","weather_icon_09.png","weather_icon_10.png","weather_icon_11.png","weather_icon_12.png","weather_icon_13.png","weather_icon_14.png","weather_icon_15.png","weather_icon_16.png","weather_icon_17.png","weather_icon_18.png","weather_icon_19.png","weather_icon_20.png","weather_icon_21.png","weather_icon_22.png","weather_icon_23.png","weather_icon_24.png","weather_icon_25.png","weather_icon_26.png","weather_icon_27.png","weather_icon_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 230,
              y: 40,
              font_array: ["weather_0.png","weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'weather_unit_c.png',
              unit_tc: 'weather_unit_c.png',
              unit_en: 'weather_unit_c.png',
              negative_image: 'weather_minus.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 131,
              y: 90,
              week_en: ["week_0_mon.png","week_1_tue.png","week_2_wed.png","week_3_thu.png","week_4_fri.png","week_5_sat.png","week_6_sun.png"],
              week_tc: ["week_0_mon.png","week_1_tue.png","week_2_wed.png","week_3_thu.png","week_4_fri.png","week_5_sat.png","week_6_sun.png"],
              week_sc: ["week_0_mon.png","week_1_tue.png","week_2_wed.png","week_3_thu.png","week_4_fri.png","week_5_sat.png","week_6_sun.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 235,
              day_startY: 89,
              day_sc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_tc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_en_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 282,
              y: 89,
              src: 'date_dot.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 64,
              hour_startY: 136,
              hour_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              hour_zero: 1,
              hour_space: 10,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 270,
              minute_startY: 136,
              minute_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              minute_zero: 1,
              minute_space: 10,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 226,
              y: 136,
              src: 'time_colon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 91,
              y: 282,
              font_array: ["stat_0.png","stat_1.png","stat_2.png","stat_3.png","stat_4.png","stat_5.png","stat_6.png","stat_7.png","stat_8.png","stat_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 116,
              y: 258,
              src: 'label_steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 265,
              y: 282,
              font_array: ["stat_0.png","stat_1.png","stat_2.png","stat_3.png","stat_4.png","stat_5.png","stat_6.png","stat_7.png","stat_8.png","stat_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 284,
              y: 258,
              src: 'label_kcal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 258,
              y: 350,
              font_array: ["bottom_0.png","bottom_1.png","bottom_2.png","bottom_3.png","bottom_4.png","bottom_5.png","bottom_6.png","bottom_7.png","bottom_8.png","bottom_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 316,
              y: 350,
              src: 'label_bat.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 112,
              y: 398,
              image_array: ["bar_00.png","bar_01.png","bar_02.png","bar_03.png","bar_04.png","bar_05.png","bar_06.png","bar_07.png","bar_08.png","bar_09.png","bar_10.png"],
              image_length: 11,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'aod Background.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 284,
              month_startY: 90,
              month_sc_array: ["aod date_0 aod.png","aod date_1 aod.png","aod date_2 aod.png","aod date_3 aod.png","aod date_4 aod.png","aod date_5 aod.png","aod date_6 aod.png","aod date_7 aod.png","aod date_8 aod.png","aod date_9 aod.png"],
              month_tc_array: ["aod date_0 aod.png","aod date_1 aod.png","aod date_2 aod.png","aod date_3 aod.png","aod date_4 aod.png","aod date_5 aod.png","aod date_6 aod.png","aod date_7 aod.png","aod date_8 aod.png","aod date_9 aod.png"],
              month_en_array: ["aod date_0 aod.png","aod date_1 aod.png","aod date_2 aod.png","aod date_3 aod.png","aod date_4 aod.png","aod date_5 aod.png","aod date_6 aod.png","aod date_7 aod.png","aod date_8 aod.png","aod date_9 aod.png"],
              month_zero: 0,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_bio_charge_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 179,
              y: 350,
              font_array: ["aod bottom_0 aod.png","aod bottom_1 aod.png","aod bottom_2 aod.png","aod bottom_3 aod.png","aod bottom_4 aod.png","aod bottom_5 aod.png","aod bottom_6 aod.png","aod bottom_7 aod.png","aod bottom_8 aod.png","aod bottom_9 aod.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_bio_charge_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 122,
              y: 350,
              src: 'aod label_hc aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 136,
              y: 38,
              image_array: ["aod weather_icon_00 aod.png","aod weather_icon_01 aod.png","aod weather_icon_02 aod.png","aod weather_icon_03 aod.png","aod weather_icon_04 aod.png","aod weather_icon_05 aod.png","aod weather_icon_06 aod.png","aod weather_icon_07 aod.png","aod weather_icon_08 aod.png","aod weather_icon_09 aod.png","aod weather_icon_10 aod.png","aod weather_icon_11 aod.png","aod weather_icon_12 aod.png","aod weather_icon_13 aod.png","aod weather_icon_14 aod.png","aod weather_icon_15 aod.png","aod weather_icon_16 aod.png","aod weather_icon_17 aod.png","aod weather_icon_18 aod.png","aod weather_icon_19 aod.png","aod weather_icon_20 aod.png","aod weather_icon_21 aod.png","aod weather_icon_22 aod.png","aod weather_icon_23 aod.png","aod weather_icon_24 aod.png","aod weather_icon_25 aod.png","aod weather_icon_26 aod.png","aod weather_icon_27 aod.png","aod weather_icon_28 aod.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 196,
              y: 40,
              font_array: ["aod weather_0 aod.png","aod weather_1 aod.png","aod weather_2 aod.png","aod weather_3 aod.png","aod weather_4 aod.png","aod weather_5 aod.png","aod weather_6 aod.png","aod weather_7 aod.png","aod weather_8 aod.png","aod weather_9 aod.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'aod weather_unit_c aod.png',
              unit_tc: 'aod weather_unit_c aod.png',
              unit_en: 'aod weather_unit_c aod.png',
              negative_image: 'aod weather_minus aod.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 124,
              y: 90,
              week_en: ["aod week_0_mon aod.png","aod week_1_tue aod.png","aod week_2_wed aod.png","aod week_3_thu aod.png","aod week_4_fri aod.png","aod week_5_sat aod.png","aod week_6_sun aod.png"],
              week_tc: ["aod week_0_mon aod.png","aod week_1_tue aod.png","aod week_2_wed aod.png","aod week_3_thu aod.png","aod week_4_fri aod.png","aod week_5_sat aod.png","aod week_6_sun aod.png"],
              week_sc: ["aod week_0_mon aod.png","aod week_1_tue aod.png","aod week_2_wed aod.png","aod week_3_thu aod.png","aod week_4_fri aod.png","aod week_5_sat aod.png","aod week_6_sun aod.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 222,
              day_startY: 90,
              day_sc_array: ["aod date_0 aod.png","aod date_1 aod.png","aod date_2 aod.png","aod date_3 aod.png","aod date_4 aod.png","aod date_5 aod.png","aod date_6 aod.png","aod date_7 aod.png","aod date_8 aod.png","aod date_9 aod.png"],
              day_tc_array: ["aod date_0 aod.png","aod date_1 aod.png","aod date_2 aod.png","aod date_3 aod.png","aod date_4 aod.png","aod date_5 aod.png","aod date_6 aod.png","aod date_7 aod.png","aod date_8 aod.png","aod date_9 aod.png"],
              day_en_array: ["aod date_0 aod.png","aod date_1 aod.png","aod date_2 aod.png","aod date_3 aod.png","aod date_4 aod.png","aod date_5 aod.png","aod date_6 aod.png","aod date_7 aod.png","aod date_8 aod.png","aod date_9 aod.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 270,
              y: 90,
              src: 'aod date_dot aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 64,
              hour_startY: 136,
              hour_array: ["aod time_0 aod.png","aod time_1 aod.png","aod time_2 aod.png","aod time_3 aod.png","aod time_4 aod.png","aod time_5 aod.png","aod time_6 aod.png","aod time_7 aod.png","aod time_8 aod.png","aod time_9 aod.png"],
              hour_zero: 1,
              hour_space: 10,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 270,
              minute_startY: 136,
              minute_array: ["aod time_0 aod.png","aod time_1 aod.png","aod time_2 aod.png","aod time_3 aod.png","aod time_4 aod.png","aod time_5 aod.png","aod time_6 aod.png","aod time_7 aod.png","aod time_8 aod.png","aod time_9 aod.png"],
              minute_zero: 1,
              minute_space: 10,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 226,
              y: 136,
              src: 'aod time_colon aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 91,
              y: 282,
              font_array: ["aod stat_0 aod.png","aod stat_1 aod.png","aod stat_2 aod.png","aod stat_3 aod.png","aod stat_4 aod.png","aod stat_5 aod.png","aod stat_6 aod.png","aod stat_7 aod.png","aod stat_8 aod.png","aod stat_9 aod.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 116,
              y: 258,
              src: 'aod label_steps aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 265,
              y: 282,
              font_array: ["aod stat_0 aod.png","aod stat_1 aod.png","aod stat_2 aod.png","aod stat_3 aod.png","aod stat_4 aod.png","aod stat_5 aod.png","aod stat_6 aod.png","aod stat_7 aod.png","aod stat_8 aod.png","aod stat_9 aod.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 284,
              y: 258,
              src: 'aod label_kcal aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 258,
              y: 350,
              font_array: ["aod bottom_0 aod.png","aod bottom_1 aod.png","aod bottom_2 aod.png","aod bottom_3 aod.png","aod bottom_4 aod.png","aod bottom_5 aod.png","aod bottom_6 aod.png","aod bottom_7 aod.png","aod bottom_8 aod.png","aod bottom_9 aod.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 316,
              y: 350,
              src: 'aod label_bat aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 112,
              y: 398,
              image_array: ["aod bar_00 aod.png","aod bar_01 aod.png","aod bar_02 aod.png","aod bar_03 aod.png","aod bar_04 aod.png","aod bar_05 aod.png","aod bar_06 aod.png","aod bar_07 aod.png","aod bar_08 aod.png","aod bar_09 aod.png","aod bar_10 aod.png"],
              image_length: 11,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 253,
              y: 348,
              w: 127,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'FlashLightScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 103,
              y: 348,
              w: 127,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1047865, url: 'page/round/index' });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 143,
              y: 419,
              w: 198,
              h: 63,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ClubCardsScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 255,
              y: 255,
              w: 153,
              h: 76,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportStatusScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 91,
              y: 255,
              w: 153,
              h: 76,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PAI_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 51,
              y: 131,
              w: 163,
              h: 109,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 265,
              y: 131,
              w: 163,
              h: 109,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 217,
              y: 131,
              w: 46,
              h: 109,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 113,
              y: 80,
              w: 250,
              h: 47,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_10 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 114,
              y: 30,
              w: 250,
              h: 47,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1051195, url: 'page/index', params: { from_wf: true} });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}