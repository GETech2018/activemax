@echo off
title Omega Chronograph - QR Amazfit Active Max

where zeus >nul 2>nul
if errorlevel 1 (
  echo Zeus CLI non trovato.
  echo Installa prima Node.js, poi esegui: npm install -g @zeppos/zeus-cli
  pause
  exit /b 1
)

echo Accesso all'account Zepp...
call zeus login
if errorlevel 1 exit /b 1

echo Generazione del QR temporaneo...
call zeus preview -t genevaw
pause
