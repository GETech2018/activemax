# Omega Chronograph — Amazfit Active Max

Quadrante analogico 480 × 480 per Amazfit Active Max (`genevaw`, Zepp OS 5 / API 4.x).

## Funzioni

- ore e minuti analogici;
- lancetta arancione dei secondi, attiva nella modalità normale;
- quadrante sinistro: percentuale e indicatore analogico della batteria;
- quadrante destro: conteggio dei passi;
- finestra a ore 6: giorno del mese;
- modalità Always-On Display semplificata con ore, minuti e data.

La lancetta dei secondi non viene mostrata in AOD per rispettare i limiti energetici e di aggiornamento dell'orologio.

## Generare il QR di installazione

1. Installare Node.js 20 o superiore sul computer.
2. Installare Zeus CLI con `npm install -g @zeppos/zeus-cli`.
3. Aprire questa cartella nel terminale ed eseguire `zeus login`.
4. Eseguire `zeus preview -t genevaw`.
5. Nell'app Zepp aprire `Profilo → Impostazioni → Informazioni` e toccare sette volte il logo Zepp per attivare la modalità sviluppatore.
6. Nell'app Zepp aprire la funzione di scansione della modalità sviluppatore e scansionare il QR mostrato da Zeus.

Il QR di anteprima è temporaneo e viene creato soltanto dopo l'accesso personale all'account sviluppatore Zepp.

## Compilare il pacchetto

Eseguire `zeus build -t genevaw`. Il file `.zab` viene scritto nella cartella `dist/`.

## Note di verifica

Il progetto usa il profilo rotondo `genevaw` da 480 × 480 dell'Active Max. Prima dell'uso quotidiano verificare sul dispositivo reale allineamento, leggibilità e comportamento dell'AOD.
