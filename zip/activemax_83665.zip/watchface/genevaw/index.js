import { getScene, SCENE_AOD } from '@zos/app'
import ui from '@zos/ui'

const img = (path) => `images/${path}`

const digits = Array.from({ length: 10 }, (_, index) => img(`digits/${index}.png`))
const days = Array.from({ length: 31 }, (_, index) => img(`date/${String(index + 1).padStart(2, '0')}.png`))

const MAIN_HANDS = {
  hour_centerX: 240,
  hour_centerY: 240,
  hour_posX: 27,
  hour_posY: 140,
  hour_path: img('point/hour.png'),
  minute_centerX: 240,
  minute_centerY: 240,
  minute_posX: 22,
  minute_posY: 188,
  minute_path: img('point/minute.png'),
  hour_cover_path: img('point/center.png'),
  hour_cover_x: 225,
  hour_cover_y: 225,
}

function createDate(showLevel) {
  ui.createWidget(ui.widget.IMG_DATE, {
    day_startX: 222,
    day_startY: 351,
    day_align: ui.align.LEFT,
    day_space: 0,
    day_zero: 0,
    day_follow: 0,
    day_is_character: true,
    day_en_array: days,
    day_sc_array: days,
    day_tc_array: days,
    show_level: showLevel,
  })
}

function createNormalFace() {
  ui.createWidget(ui.widget.IMG, {
    x: 0,
    y: 0,
    src: img('bg.png'),
    show_level: ui.show_level.ONLY_NORMAL,
  })

  ui.createWidget(ui.widget.IMG_POINTER, {
    src: img('point/sub_pointer.png'),
    center_x: 132,
    center_y: 236,
    x: 8,
    y: 55,
    type: ui.data_type.BATTERY,
    start_angle: -120,
    end_angle: 120,
    show_level: ui.show_level.ONLY_NORMAL,
  })

  ui.createWidget(ui.widget.IMG, {
    x: 117,
    y: 203,
    src: img('icons/bat.png'),
    show_level: ui.show_level.ONLY_NORMAL,
  })

  ui.createWidget(ui.widget.TEXT_IMG, {
    x: 96,
    y: 241,
    w: 72,
    type: ui.data_type.BATTERY,
    font_array: digits,
    h_space: -1,
    align_h: ui.align.CENTER_H,
    unit_en: img('digits/percent.png'),
    unit_sc: img('digits/percent.png'),
    unit_tc: img('digits/percent.png'),
    invalid_image: img('digits/dash.png'),
    show_level: ui.show_level.ONLY_NORMAL,
  })

  ui.createWidget(ui.widget.IMG, {
    x: 313,
    y: 205,
    src: img('icons/steps.png'),
    show_level: ui.show_level.ONLY_NORMAL,
  })

  ui.createWidget(ui.widget.TEXT_IMG, {
    x: 293,
    y: 229,
    w: 80,
    type: ui.data_type.STEP,
    font_array: digits,
    h_space: -2,
    align_h: ui.align.CENTER_H,
    invalid_image: img('digits/dash.png'),
    show_level: ui.show_level.ONLY_NORMAL,
  })

  ui.createWidget(ui.widget.IMG, {
    x: 313,
    y: 255,
    src: img('icons/passi.png'),
    show_level: ui.show_level.ONLY_NORMAL,
  })

  createDate(ui.show_level.ONLY_NORMAL)

  ui.createWidget(ui.widget.TIME_POINTER, {
    ...MAIN_HANDS,
    second_centerX: 240,
    second_centerY: 240,
    second_posX: 11,
    second_posY: 214,
    second_path: img('point/second.png'),
    show_level: ui.show_level.ONLY_NORMAL,
  })
}

function createAodFace() {
  ui.createWidget(ui.widget.IMG, {
    x: 0,
    y: 0,
    src: img('aod_bg.png'),
    show_level: ui.show_level.ONAL_AOD,
  })

  createDate(ui.show_level.ONAL_AOD)

  ui.createWidget(ui.widget.TIME_POINTER, {
    ...MAIN_HANDS,
    show_level: ui.show_level.ONAL_AOD,
  })
}

WatchFace({
  initView() {
    if (getScene() === SCENE_AOD) {
      createAodFace()
    } else {
      createNormalFace()
    }
  },
  build() {
    this.initView()
  },
})
