#!/bin/sh
set -eu

if ! command -v zeus >/dev/null 2>&1; then
  echo "Zeus CLI non trovato. Installa Node.js, poi esegui: npm install -g @zeppos/zeus-cli"
  exit 1
fi

echo "Accesso all'account Zepp..."
zeus login

echo "Generazione del QR temporaneo..."
zeus preview -t genevaw
