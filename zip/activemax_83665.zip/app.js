import { log } from '@zos/utils'

const logger = log.getLogger('omega-chronograph')

App({
  globalData: {},
  onCreate() {
    logger.log('Omega Chronograph created')
  },
  onDestroy() {
    logger.log('Omega Chronograph destroyed')
  },
})
