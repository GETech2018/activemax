﻿    /*
    ** Watch_Face_Editor tool v 18.1
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

/*! Garmin Marq Capitain EVO - tap to switch fields | (c) 2026 ArtBombs | github.com/ArtBombs */
console.log("Garmin Marq Capitain EVO (c) 2026 ArtBombs - github.com/ArtBombs");const EVO_KEYS={b2:"marq_capitain_evo_b2",b5:"marq_capitain_evo_b5",b6:"marq_capitain_evo_b6"};let evo_mode={b2:0,b5:0,b6:0},evo_modes={b2:[],b5:[],b6:[]},evo_timer=null;function evo_list(e){let t=[];for(let o=0;o<e.length;o++)try{let n=e[o]();n&&n.setProperty&&t.indexOf(n)<0&&t.push(n)}catch(e){}return t}function evo_join(){let e=[];for(let t=0;t<arguments.length;t++){let o=arguments[t];for(let t=0;t<o.length;t++)e.indexOf(o[t])<0&&e.push(o[t])}return e}function evo_setVisible(e,t){try{e.setProperty(hmUI.prop.VISIBLE,t)}catch(e){}}function evo_apply(e){let t=evo_modes[e];if(!t||!t.length)return;let o=t[evo_mode[e]]||[];for(let n=0;n<t.length;n++)if(n!==evo_mode[e])for(let e=0;e<t[n].length;e++)o.indexOf(t[n][e])<0&&evo_setVisible(t[n][e],!1);for(let e=0;e<o.length;e++)evo_setVisible(o[e],!0)}function evo_load(e){let t=evo_modes[e].length,o=0;try{o=hmFS.SysProGetInt(EVO_KEYS[e])}catch(e){o=0}o>=0&&o<t||(o=0),evo_mode[e]=o}function evo_next(e){let t=evo_modes[e].length;if(t){evo_mode[e]=(evo_mode[e]+1)%t;try{hmFS.SysProSetInt(EVO_KEYS[e],evo_mode[e])}catch(e){}evo_apply(e),"b6"===e&&evo_compassSync(!0)}}function b2_toggle(){evo_next("b2")}function b5_toggle(){evo_next("b5")}function b6_toggle(){evo_next("b6")}function evo_isWatchface(){try{return hmSetting.getScreenType()==hmSetting.screen_type.WATCHFACE}catch(e){return!1}}function evo_compassSensor(){try{if("undefined"!=typeof compass&&compass)return compass}catch(e){}return null}function evo_compassRefresh(e){try{if(!e||!e.direction_angle||"INVALID"==e.direction_angle)return;let t=parseInt(e.direction_angle);if(isNaN(t))return;let o=evo_list([()=>normal_compass_direction_pointer_img])[0];o&&o.setProperty(hmUI.prop.ANGLE,-t);let n=evo_list([()=>normal_compass_text_font])[0];n&&n.setProperty(hmUI.prop.TEXT,t+"\xb0");let r=evo_list([()=>normal_compass_direction_img_level])[0],_=parseInt((t+22.5)/45);_>7&&(_=0),r&&r.setProperty(hmUI.prop.SRC,normal_compass_direction_arr[_])}catch(e){}}function evo_compassSync(e){let t=evo_compassSensor();if(t)try{0!==evo_mode.b6?(evo_isWatchface()&&t.start(),e&&evo_compassRefresh(t)):t.stop()}catch(e){}}function evo_resume(){evo_compassSync(!0)}
        // end user_functions.js

        let editBg = ''
        let normal_system_clock_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_wind_icon_img = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_wind_text_text_img = ''
        let normal_compass_icon_img = ''
        let normal_compass_direction_pointer_img = ''
        let normal_compass_text_font = ''
        let normal_compass_direction_img_level = ''
        let normal_compass_direction_arr = ["Compass-C-0---Copia.png", "Compass-C-45---Copia.png", "Compass-C-90---Copia.png", "Compass-C-135---Copia.png", "Compass-C-180---Copia.png", "Compass-C-225---Copia.png", "Compass-C-270---Copia.png", "Compass-C-315---Copia.png"];
        let normal_altimeter_icon_img = ''
        let normal_altitude_target_text_img = ''
        let normal_altimeter_current_text_font = ''
        let normal_spo2_icon_img = ''
        let normal_spo2_text_text_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_distance_icon_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_fat_burning_icon_img = ''
        let normal_fat_burning_current_text_img = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_font = ''
        let normal_temperature_low_text_font = ''
        let normal_temperature_current_text_img = ''
        let normal_sun_high_text_font = ''
        let normal_sun_low_text_font = ''
        let normal_moon_image_progress_img_level = ''
        let normal_moon_high_text_font = ''
        let normal_group_ForecastWeather = ''
        let normal_canvas1 = '';
        let normal_canvas2 = '';
        let normal_forecast_date_week_font = new Array(3);
        let normal_forecast_date_week_font_Array = ['MO', 'TU', 'WE', 'TH', 'FR', 'SA', 'SU'];
        let normal_forecast_low_text_font = new Array(3);
        let normal_forecast_high_text_font = new Array(3);
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 480,
              // h: 480,
              // AOD_show: False,
              bg_config: [
                { id: 1, preview: 'WF---Garmin-Captain-01.png', path: 'WF---Garmin-Captain-01.png' },
                { id: 2, preview: 'WF---Garmin-Captain-01b2.png', path: 'WF---Garmin-Captain-01b2.png' },
                { id: 3, preview: 'WF---Garmin-Captain-01c.png', path: 'WF---Garmin-Captain-01c.png' },
              ],
              count: 3,
              default_id: 1,
              fg: '.png',
              tips_bg: '.png',
              tips_x: 0,
              tips_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 228,
              y: 156,
              src: '0032b.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 267,
              y: 129,
              image_array: ["BAT-10.png","BAT-20.png","BAT-30.png","BAT-40.png","BAT-50.png","BAT-60.png","BAT-70.png","BAT-80.png","BAT-90.png","BAT-100.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 182,
              y: 127,
              week_en: ["WF---Garmin-Captain-WEEK-01.png","WF---Garmin-Captain-WEEK-02.png","WF---Garmin-Captain-WEEK-03.png","WF---Garmin-Captain-WEEK-04.png","WF---Garmin-Captain-WEEK-05.png","WF---Garmin-Captain-WEEK-06.png","WF---Garmin-Captain-WEEK-07.png"],
              week_tc: ["WF---Garmin-Captain-WEEK-01.png","WF---Garmin-Captain-WEEK-02.png","WF---Garmin-Captain-WEEK-03.png","WF---Garmin-Captain-WEEK-04.png","WF---Garmin-Captain-WEEK-05.png","WF---Garmin-Captain-WEEK-06.png","WF---Garmin-Captain-WEEK-07.png"],
              week_sc: ["WF---Garmin-Captain-WEEK-01.png","WF---Garmin-Captain-WEEK-02.png","WF---Garmin-Captain-WEEK-03.png","WF---Garmin-Captain-WEEK-04.png","WF---Garmin-Captain-WEEK-05.png","WF---Garmin-Captain-WEEK-06.png","WF---Garmin-Captain-WEEK-07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 232,
              day_startY: 126,
              day_sc_array: ["WF---Garmin-Captain-DayN-00.png","WF---Garmin-Captain-DayN-01.png","WF---Garmin-Captain-DayN-02.png","WF---Garmin-Captain-DayN-03.png","WF---Garmin-Captain-DayN-04.png","WF---Garmin-Captain-DayN-05.png","WF---Garmin-Captain-DayN-06.png","WF---Garmin-Captain-DayN-07.png","WF---Garmin-Captain-DayN-08.png","WF---Garmin-Captain-DayN-09.png"],
              day_tc_array: ["WF---Garmin-Captain-DayN-00.png","WF---Garmin-Captain-DayN-01.png","WF---Garmin-Captain-DayN-02.png","WF---Garmin-Captain-DayN-03.png","WF---Garmin-Captain-DayN-04.png","WF---Garmin-Captain-DayN-05.png","WF---Garmin-Captain-DayN-06.png","WF---Garmin-Captain-DayN-07.png","WF---Garmin-Captain-DayN-08.png","WF---Garmin-Captain-DayN-09.png"],
              day_en_array: ["WF---Garmin-Captain-DayN-00.png","WF---Garmin-Captain-DayN-01.png","WF---Garmin-Captain-DayN-02.png","WF---Garmin-Captain-DayN-03.png","WF---Garmin-Captain-DayN-04.png","WF---Garmin-Captain-DayN-05.png","WF---Garmin-Captain-DayN-06.png","WF---Garmin-Captain-DayN-07.png","WF---Garmin-Captain-DayN-08.png","WF---Garmin-Captain-DayN-09.png"],
              day_zero: 1,
              day_space: -5,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 231,
              y: 348,
              src: 'KT.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 181,
              y: 274,
              image_array: ["COMPASS-Wind-01.png","COMPASS-Wind-02.png","COMPASS-Wind-03.png","COMPASS-Wind-04.png","COMPASS-Wind-05.png","COMPASS-Wind-06.png","COMPASS-Wind-07.png","COMPASS-Wind-08.png"],
              image_length: 8,
              shortcut: true,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 223,
              y: 320,
              font_array: ["WF---Garmin-Captain-WindF-00.png","WF---Garmin-Captain-WindF-01.png","WF---Garmin-Captain-WindF-02.png","WF---Garmin-Captain-WindF-03.png","WF---Garmin-Captain-WindF-04.png","WF---Garmin-Captain-WindF-05.png","WF---Garmin-Captain-WindF-06.png","WF---Garmin-Captain-WindF-07.png","WF---Garmin-Captain-WindF-08.png","WF---Garmin-Captain-WindF-09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_compass_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 228,
              y: 262,
              src: 'WF---Garmin-Captain-05a.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            
            // normal_compass_custom_pointer_img = hmUI.createWidget(hmUI.widget.CUSTOM_POINTER, {
              // src: 'Compass-O.png',
              // center_x: 240,
              // center_y: 333,
              // x: 71,
              // y: 71,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.COMPASS,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            //#region Compass_Pointer
            normal_compass_direction_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 71,
              pos_y: 333 - 71,
              center_x: 240,
              center_y: 333,
              src: 'Compass-O.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            //#endregion

            normal_compass_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 168,
              y: 293,
              w: 150,
              h: 34,
              text_size: 26,
              char_space: 0,
              color: 0xFF9CFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_type: 1,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_compass_direction_img_level = hmUI.createWidget(hmUI.widget.IMG, {
              x: 201,
              y: 338,
              src: 'Compass-C-0---Copia.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
              // type: hmUI.data_type.COMPASS,
            });

            normal_altimeter_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 188,
              y: 283,
              src: 'Compass-Of.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 204,
              y: 340,
              font_array: ["WF---Garmin-Captain-DayN-00.png","WF---Garmin-Captain-DayN-01.png","WF---Garmin-Captain-DayN-02.png","WF---Garmin-Captain-DayN-03.png","WF---Garmin-Captain-DayN-04.png","WF---Garmin-Captain-DayN-05.png","WF---Garmin-Captain-DayN-06.png","WF---Garmin-Captain-DayN-07.png","WF---Garmin-Captain-DayN-08.png","WF---Garmin-Captain-DayN-09.png"],
              padding: false,
              h_space: -5,
              unit_sc: 'WF---Garmin-Captain-DayN-m0.png',
              unit_tc: 'WF---Garmin-Captain-DayN-m0.png',
              unit_en: 'WF---Garmin-Captain-DayN-m0.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 165,
              y: 304,
              w: 150,
              h: 30,
              text_size: 20,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 80,
              y: 242,
              src: 'WF---Garmin-Captain-HertN-L0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 99,
              y: 242,
              font_array: ["WF---Garmin-Captain-HertN-00.png","WF---Garmin-Captain-HertN-01.png","WF---Garmin-Captain-HertN-02.png","WF---Garmin-Captain-HertN-03.png","WF---Garmin-Captain-HertN-04.png","WF---Garmin-Captain-HertN-05.png","WF---Garmin-Captain-HertN-06.png","WF---Garmin-Captain-HertN-07.png","WF---Garmin-Captain-HertN-08.png","WF---Garmin-Captain-HertN-09.png"],
              padding: false,
              h_space: -4,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 77,
              y: 237,
              src: 'WF---Garmin-Captain-TempN-br0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 99,
              y: 210,
              font_array: ["WF---Garmin-Captain-HertN-00.png","WF---Garmin-Captain-HertN-01.png","WF---Garmin-Captain-HertN-02.png","WF---Garmin-Captain-HertN-03.png","WF---Garmin-Captain-HertN-04.png","WF---Garmin-Captain-HertN-05.png","WF---Garmin-Captain-HertN-06.png","WF---Garmin-Captain-HertN-07.png","WF---Garmin-Captain-HertN-08.png","WF---Garmin-Captain-HertN-09.png"],
              padding: false,
              h_space: -4,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 80,
              y: 211,
              src: 'WF---Garmin-Captain-HertN-H0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 99,
              y: 242,
              font_array: ["WF---Garmin-Captain-HertN-00.png","WF---Garmin-Captain-HertN-01.png","WF---Garmin-Captain-HertN-02.png","WF---Garmin-Captain-HertN-03.png","WF---Garmin-Captain-HertN-04.png","WF---Garmin-Captain-HertN-05.png","WF---Garmin-Captain-HertN-06.png","WF---Garmin-Captain-HertN-07.png","WF---Garmin-Captain-HertN-08.png","WF---Garmin-Captain-HertN-09.png"],
              padding: false,
              h_space: -4,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 80,
              y: 241,
              src: 'WF---Garmin-Captain-HertN-S0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 77,
              y: 237,
              src: 'WF---Garmin-Captain-TempN-brrrr0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 99,
              y: 211,
              font_array: ["WF---Garmin-Captain-HertN-00.png","WF---Garmin-Captain-HertN-01.png","WF---Garmin-Captain-HertN-02.png","WF---Garmin-Captain-HertN-03.png","WF---Garmin-Captain-HertN-04.png","WF---Garmin-Captain-HertN-05.png","WF---Garmin-Captain-HertN-06.png","WF---Garmin-Captain-HertN-07.png","WF---Garmin-Captain-HertN-08.png","WF---Garmin-Captain-HertN-09.png"],
              padding: false,
              h_space: -4,
              unit_sc: 'WF---Garmin-Captain-HertN-0m0.png',
              unit_tc: 'WF---Garmin-Captain-HertN-0m0.png',
              unit_en: 'WF---Garmin-Captain-HertN-0m0.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 80,
              y: 210,
              src: 'WF---Garmin-Captain-HertN-D0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 80,
              y: 241,
              src: 'WF---Garmin-Captain-HertN-F0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 99,
              y: 242,
              font_array: ["WF---Garmin-Captain-HertN-00.png","WF---Garmin-Captain-HertN-01.png","WF---Garmin-Captain-HertN-02.png","WF---Garmin-Captain-HertN-03.png","WF---Garmin-Captain-HertN-04.png","WF---Garmin-Captain-HertN-05.png","WF---Garmin-Captain-HertN-06.png","WF---Garmin-Captain-HertN-07.png","WF---Garmin-Captain-HertN-08.png","WF---Garmin-Captain-HertN-09.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 77,
              y: 237,
              src: 'WF---Garmin-Captain-TempN-brr2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 99,
              y: 211,
              font_array: ["WF---Garmin-Captain-HertN-00.png","WF---Garmin-Captain-HertN-01.png","WF---Garmin-Captain-HertN-02.png","WF---Garmin-Captain-HertN-03.png","WF---Garmin-Captain-HertN-04.png","WF---Garmin-Captain-HertN-05.png","WF---Garmin-Captain-HertN-06.png","WF---Garmin-Captain-HertN-07.png","WF---Garmin-Captain-HertN-08.png","WF---Garmin-Captain-HertN-09.png"],
              padding: true,
              h_space: -4,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 80,
              y: 210,
              src: 'WF---Garmin-Captain-HertN-C0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 252,
              y: 245,
              image_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 390,
              y: 199,
              w: 150,
              h: 30,
              text_size: 15,
              char_space: 0,
              color: 0xFFFF0000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 393,
              y: 218,
              w: 150,
              h: 30,
              text_size: 15,
              char_space: 0,
              color: 0xFF80FFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 316,
              y: 205,
              font_array: ["WF---Garmin-Captain-TempN-00.png","WF---Garmin-Captain-TempN-01.png","WF---Garmin-Captain-TempN-02.png","WF---Garmin-Captain-TempN-03.png","WF---Garmin-Captain-TempN-04.png","WF---Garmin-Captain-TempN-05.png","WF---Garmin-Captain-TempN-06.png","WF---Garmin-Captain-TempN-07.png","WF---Garmin-Captain-TempN-08.png","WF---Garmin-Captain-TempN-09.png"],
              padding: false,
              h_space: -7,
              unit_sc: 'WF---Garmin-Captain-TempN-O.png',
              unit_tc: 'WF---Garmin-Captain-TempN-O.png',
              unit_en: 'WF---Garmin-Captain-TempN-O.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 357,
              y: 172,
              w: 150,
              h: 30,
              text_size: 20,
              char_space: 0,
              color: 0xFF80FFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 357,
              y: 277,
              w: 150,
              h: 30,
              text_size: 20,
              char_space: 0,
              color: 0xFFFF0000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 342,
              y: 211,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 293,
              y: 224,
              w: 155,
              h: 28,
              text_size: 20,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.MOON_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();            
            // normal_Weather_FewDays = hmUI.createWidget(hmUI.widget.FewDays, {
              // x: 328,
              // y: 238,
              // ColumnWidth: 30,
              // DaysCount: 3,
            // });
            
            normal_group_ForecastWeather = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 328,
              y: 238,
              h: 0,
              w: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            //#region draw
            function drawLine(canvas1, canvas2, x1, y1, x2, y2, color, line_width) {
              if (x1 > x2) {
                let temp_x = x1;
                let temp_y = y1;
                x1 = x2;
                y1 = y2;
                x2 = temp_x;
                y2 = temp_y;
              };
              canvas2.setPaint({ color: color, line_width: line_width });
              canvas2.drawLine({ x1: x1, y1: y1, x2: x2, y2: y2 });
            };
            
            function drawRect(canvas1, canvas2, x1, y1, x2, y2, color) {
              if (x1 > x2) {
                let temp_x = x1;
                let temp_y = y1;
                x1 = x2;
                y1 = y2;
                x2 = temp_x;
                y2 = temp_y;
              };
              
              canvas2.drawRect({ x1: x1, y1: y1, x2: x2, y2: y2, color: color });
            };
            
            function drawCircle(canvas1, canvas2, center_x, center_y, color, radius) {
              canvas2.drawCircle({ center_x: center_x, center_y: center_y, radius: radius, color: color });
            };
            
            function drawGraphPoint(canvas1, canvas2, x, y, color, pointSize, pointType) {
              switch (pointType) {
                case 1:
                  x -= pointSize/2;
                  y -= pointSize/2;
                  drawRect(canvas1, canvas2, x, y, x+pointSize, y+pointSize, color);
                  break;
                case 2:
                  let posX = x - pointSize/2;
                  let posY = y - pointSize/2;
                  drawRect(canvas1, canvas2, posX, posY, posX+pointSize, posY+pointSize, color );
                  posX = x - pointSize/4;
                  posY = y - pointSize/4;
                  drawRect(canvas1, canvas2, posX, posY, posX+pointSize/2, posY+pointSize/2, 0xffffff );
                  break;
                case 3:
                  drawCircle(canvas1, canvas2, x, y, color, pointSize/2 );
                  break;
                case 4:
                  drawCircle(canvas1, canvas2, x, y, color, pointSize/2 );
                  drawCircle(canvas1, canvas2, x, y, 0xffffff, pointSize/4 );
                  break;
              }
            };

            //#endregion
            

            //#region graphScale
            function graphScale(heightGraph, maxPointSize, minPointSize, forecastData, daysCount) {
              console.log(`function graphScale`);
              heightGraph -= (maxPointSize + minPointSize) / 2;
              let high = -300;
              let low = 300;
              for (let index = 0; index < daysCount; index++) {
                if (index < forecastData.length) {
                  let item = forecastData[index];
                  if (item.high > high) high = item.high;;
                  if (item.low < low) low = item.low; ;
                } // end if
              } // end for
              let delta = high - low;
              let scale = heightGraph / delta;
              console.log(`heightGraph: ${heightGraph}; high: ${high}; low : ${low}`);
              return {graphScale: scale, maximal_temp: high};
            };

            //#endregion

            //#region screenType
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              normal_canvas1 = normal_group_ForecastWeather.createWidget(hmUI.widget.CANVAS, {
                x: 0,
                y: 0,
                w: 0,
                h: 0,
              });

              normal_canvas2 = normal_group_ForecastWeather.createWidget(hmUI.widget.CANVAS, {
                x: -3,
                y: 0,
                w: 480,
                h: 480,
              });
            };
            //#endregion

            // normal_forecast_date_week_font = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_Options, {
              // x: -2,
              // y: -37,
              // w: 150,
              // h: 30,
              // text_size: 15,
              // char_space: 0,
              // line_space: 0,
              // alpha: 255,
              // color: 0xFFFFFFFF,
              // color_2: 0xFFFF0000,
              // use_color_2: True,
              // align_h: hmUI.align.LEFT,
              // align_v: hmUI.align.TOP,
              // text_style: hmUI.text_style.ELLIPSIS,
              // type: hmUI.data_type.forecast_date_week_img,
              // unit_string: MO, TU, WE, TH, FR, SA, SU,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //#region screenType
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 3; i++) {
                normal_forecast_date_week_font[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT, {
                  x: -2 + i*30,
                  y: -37,
                  w: 150,
                  h: 30,
                  text_size: 15,
                  char_space: 0,
                  line_space: 0,
                  color: 0xFFFFFFFF,
                  // color_2: 0xFFFF0000,
                  align_h: hmUI.align.LEFT,
                  align_v: hmUI.align.TOP,
                  text_style: hmUI.text_style.ELLIPSIS,
                  // unit_string: MO, TU, WE, TH, FR, SA, SU,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //#endregion

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_forecast_low_text_font = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_Options, {
              // x: -9,
              // y: 0,
              // w: 150,
              // h: 30,
              // text_size: 14,
              // char_space: 0,
              // line_space: 0,
              // alpha: 255,
              // color: 0xFFFFFFFF,
              // color_2: 0xFFFF0000,
              // use_color_2: False,
              // align_h: hmUI.align.LEFT,
              // align_v: hmUI.align.TOP,
              // text_style: hmUI.text_style.ELLIPSIS,
              // type: hmUI.data_type.forecast_low_text_font,
              // unit_type: 1,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //#region screenType
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 3; i++) {
                normal_forecast_low_text_font[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT, {
                  x: 0 + i*30,
                  y: 0,
                  w: 150,
                  h: 30,
                  text_size: 14,
                  char_space: 0,
                  line_space: 0,
                  color: 0xFFFFFFFF,
                  align_h: hmUI.align.LEFT,
                  align_v: hmUI.align.TOP,
                  text_style: hmUI.text_style.ELLIPSIS,
                  // unit_type: 1,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //#endregion

            // normal_forecast_high_text_font = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_Options, {
              // x: -9,
              // y: -21,
              // w: 150,
              // h: 30,
              // text_size: 14,
              // char_space: 0,
              // line_space: 0,
              // alpha: 255,
              // color: 0xFFFFFFFF,
              // color_2: 0xFFFF0000,
              // use_color_2: False,
              // align_h: hmUI.align.LEFT,
              // align_v: hmUI.align.TOP,
              // text_style: hmUI.text_style.ELLIPSIS,
              // type: hmUI.data_type.forecast_high_text_font,
              // unit_type: 1,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //#region screenType
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 3; i++) {
                normal_forecast_high_text_font[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT, {
                  x: 0 + i*30,
                  y: -21,
                  w: 150,
                  h: 30,
                  text_size: 14,
                  char_space: 0,
                  line_space: 0,
                  color: 0xFFFFFFFF,
                  align_h: hmUI.align.LEFT,
                  align_v: hmUI.align.TOP,
                  text_style: hmUI.text_style.ELLIPSIS,
                  // unit_type: 1,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //#endregion

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'WF---Garmin-Captain-02.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 240,
              hour_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'WF---Garmin-Captain-03.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 240,
              minute_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'WF---Garmin-Captain-04.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 240,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'WF---Garmin-Captain-01-AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 231,
              day_startY: 126,
              day_sc_array: ["WF---Garmin-Captain-DayN-00.png","WF---Garmin-Captain-DayN-01.png","WF---Garmin-Captain-DayN-02.png","WF---Garmin-Captain-DayN-03.png","WF---Garmin-Captain-DayN-04.png","WF---Garmin-Captain-DayN-05.png","WF---Garmin-Captain-DayN-06.png","WF---Garmin-Captain-DayN-07.png","WF---Garmin-Captain-DayN-08.png","WF---Garmin-Captain-DayN-09.png"],
              day_tc_array: ["WF---Garmin-Captain-DayN-00.png","WF---Garmin-Captain-DayN-01.png","WF---Garmin-Captain-DayN-02.png","WF---Garmin-Captain-DayN-03.png","WF---Garmin-Captain-DayN-04.png","WF---Garmin-Captain-DayN-05.png","WF---Garmin-Captain-DayN-06.png","WF---Garmin-Captain-DayN-07.png","WF---Garmin-Captain-DayN-08.png","WF---Garmin-Captain-DayN-09.png"],
              day_en_array: ["WF---Garmin-Captain-DayN-00.png","WF---Garmin-Captain-DayN-01.png","WF---Garmin-Captain-DayN-02.png","WF---Garmin-Captain-DayN-03.png","WF---Garmin-Captain-DayN-04.png","WF---Garmin-Captain-DayN-05.png","WF---Garmin-Captain-DayN-06.png","WF---Garmin-Captain-DayN-07.png","WF---Garmin-Captain-DayN-08.png","WF---Garmin-Captain-DayN-09.png"],
              day_zero: 1,
              day_space: -5,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              // alpha: 180,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day.setAlpha(180);

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 182,
              y: 127,
              week_en: ["WF---Garmin-Captain-WEEK-01.png","WF---Garmin-Captain-WEEK-02.png","WF---Garmin-Captain-WEEK-03.png","WF---Garmin-Captain-WEEK-04.png","WF---Garmin-Captain-WEEK-05.png","WF---Garmin-Captain-WEEK-06.png","WF---Garmin-Captain-WEEK-07.png"],
              week_tc: ["WF---Garmin-Captain-WEEK-01.png","WF---Garmin-Captain-WEEK-02.png","WF---Garmin-Captain-WEEK-03.png","WF---Garmin-Captain-WEEK-04.png","WF---Garmin-Captain-WEEK-05.png","WF---Garmin-Captain-WEEK-06.png","WF---Garmin-Captain-WEEK-07.png"],
              week_sc: ["WF---Garmin-Captain-WEEK-01.png","WF---Garmin-Captain-WEEK-02.png","WF---Garmin-Captain-WEEK-03.png","WF---Garmin-Captain-WEEK-04.png","WF---Garmin-Captain-WEEK-05.png","WF---Garmin-Captain-WEEK-06.png","WF---Garmin-Captain-WEEK-07.png"],
              // alpha: 180,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img.setAlpha(180);

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 262,
              y: 129,
              image_array: ["BAT-10.png","BAT-20.png","BAT-30.png","BAT-40.png","BAT-50.png","BAT-60.png","BAT-70.png","BAT-80.png","BAT-90.png","BAT-100.png"],
              image_length: 10,
              // alpha: 180,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level.setAlpha(180);

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'WF---Garmin-Captain-02.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 240,
              hour_posY: 240,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'WF---Garmin-Captain-03.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 240,
              minute_posY: 240,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: Oi, sua mulher está por perto?,
              // conneсnt_vibrate_type: 25,
              // conneсnt_toast_text: Eu to só de calcinha!,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Oi, sua mulher está por perto?"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "Eu to só de calcinha!"});
                  vibro(25);
                }
              });
            }

            // end vibration when connecting or disconnecting
            //#region vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            //#endregion

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 30,
              y: 30,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0078.png',
              normal_src: '0078.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'FlashLightScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'HmReStartScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 335,
              y: 199,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0078.png',
              normal_src: '0078.png',
              click_func: (button_widget) => {
                b2_toggle();
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'BaroAltimeterScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 416,
              y: 199,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0078.png',
              normal_src: '0078.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1051195, url: 'page/index', params: { from_wf: true} });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 403,
              y: 77,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0078.png',
              normal_src: '0078.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AppListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 67,
              y: 199,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0078.png',
              normal_src: '0078.png',
              click_func: (button_widget) => {
                b5_toggle();
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'spo_HomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 216,
              y: 308,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0078.png',
              normal_src: '0078.png',
              click_func: (button_widget) => {
                b6_toggle();
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'CompassScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 182,
              y: 94,
              w: 118,
              h: 59,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0078.png',
              normal_src: '0078.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

try{const _=evo_list([()=>normal_wind_direction_image_progress_img_level,()=>normal_wind_image_progress_img_level,()=>normal_wind_image_progress_img_progress,()=>normal_wind_text_text_img,()=>normal_wind_text_separator_img,()=>normal_wind_current_text_font,()=>normal_wind_speed_text_img,()=>normal_wind_speed_separator_img,()=>normal_wind_speed_text_font,()=>normal_wind_pointer_progress_img_pointer,()=>normal_wind_icon_img]),r=evo_list([()=>normal_compass_direction_pointer_img,()=>normal_compass_direction_cover_pointer_img]),e=evo_list([()=>normal_compass_icon_img,()=>normal_compass_direction_img_level,()=>normal_compass_text_img,()=>normal_compass_separator_img,()=>normal_compass_text_font]),t=evo_list([()=>normal_altimeter_icon_img,()=>normal_altimeter_text_text_img,()=>normal_altimeter_text_separator_img,()=>normal_altimeter_current_text_font,()=>normal_pressure_text_text_img,()=>normal_pressure_text_separator_img,()=>normal_pressure_text_font,()=>normal_altitude_target_text_img,()=>normal_altitude_target_separator_img,()=>normal_altitude_target_text_font,()=>normal_altimeter_pointer_progress_img_pointer]);evo_modes.b6=[_,evo_join(r,e),evo_join(r,t)];const o=evo_list([()=>normal_heart_rate_image_progress_img_level,()=>normal_heart_rate_image_progress_img_progress,()=>normal_heart_rate_text_text_img,()=>normal_heart_rate_text_separator_img,()=>normal_heart_rate_text_font,()=>normal_heart_rate_pointer_progress_img_pointer,()=>normal_heart_rate_icon_img]),a=evo_list([()=>normal_spo2_text_text_img,()=>normal_spo2_text_separator_img,()=>normal_spo2_current_text_font,()=>normal_spo2_icon_img]),m=evo_list([()=>normal_calorie_image_progress_img_level,()=>normal_calorie_image_progress_img_progress,()=>normal_calorie_current_text_img,()=>normal_calorie_current_separator_img,()=>normal_calorie_current_text_font,()=>normal_calorie_target_text_img,()=>normal_calorie_target_separator_img,()=>normal_calorie_target_text_font,()=>normal_calorie_pointer_progress_img_pointer,()=>normal_calorie_icon_img]),n=evo_list([()=>normal_fat_burning_image_progress_img_level,()=>normal_fat_burning_image_progress_img_progress,()=>normal_fat_burning_current_text_img,()=>normal_fat_burning_current_separator_img,()=>normal_fat_burning_current_text_font,()=>normal_fat_burning_target_text_img,()=>normal_fat_burning_target_separator_img,()=>normal_fat_burning_target_text_font,()=>normal_fat_burning_pointer_progress_img_pointer,()=>normal_fat_burning_icon_img]),i=evo_list([()=>normal_step_image_progress_img_level,()=>normal_step_image_progress_img_progress,()=>normal_step_current_text_img,()=>normal_step_current_separator_img,()=>normal_step_current_text_font,()=>normal_step_target_text_img,()=>normal_step_target_separator_img,()=>normal_step_target_text_font,()=>normal_step_pointer_progress_img_pointer,()=>normal_step_icon_img]),l=evo_list([()=>normal_distance_text_text_img,()=>normal_distance_text_separator_img,()=>normal_distance_current_text_font,()=>normal_distance_icon_img]);evo_modes.b5=[evo_join(o,a),evo_join(m,n),evo_join(i,l)];const g=evo_list([()=>normal_weather_image_progress_img_level,()=>normal_temperature_current_text_img,()=>normal_temperature_current_separator_img,()=>normal_temperature_current_text_font,()=>normal_temperature_low_text_img,()=>normal_temperature_low_separator_img,()=>normal_temperature_low_text_font,()=>normal_temperature_high_text_img,()=>normal_temperature_high_separator_img,()=>normal_temperature_high_text_font,()=>normal_temperature_max_min_text_img,()=>normal_temperature_max_min_separator_img,()=>normal_temperature_max_min_text_font,()=>normal_city_name_text,()=>normal_temperature_icon_img]),s=evo_list([()=>normal_sun_image_progress_img_level,()=>normal_sun_image_progress_img_progress,()=>normal_sun_high_text_img,()=>normal_sun_high_separator_img,()=>normal_sun_high_text_font,()=>normal_sun_low_text_img,()=>normal_sun_low_separator_img,()=>normal_sun_low_text_font,()=>normal_sun_current_text_img,()=>normal_sun_current_separator_img,()=>normal_sun_pointer_progress_img_pointer,()=>normal_sun_icon_img]),p=evo_list([()=>normal_moon_image_progress_img_level,()=>normal_moon_high_text_img,()=>normal_moon_high_separator_img,()=>normal_moon_high_text_font,()=>normal_moon_low_text_img,()=>normal_moon_low_separator_img,()=>normal_moon_low_text_font,()=>normal_moon_current_text_img,()=>normal_moon_current_separator_img,()=>normal_moon_pointer_progress_img_pointer,()=>normal_moon_icon_img]),c=evo_list([()=>normal_group_ForecastWeather,()=>normal_forecast_background]);if(evo_modes.b2=[g,evo_join(s,p),c],["b2","b5","b6"].forEach(function(_){evo_load(_),evo_apply(_)}),0===evo_mode.b6)try{evo_timer=timer.createTimer(500,1e3,function(){try{timer.stopTimer(evo_timer)}catch(_){}evo_compassSync(!1)},{})}catch(_){}}catch(_){console.log("EVO erro: "+_)}
            // end user_script_end.js

            const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
            //#region weather_few_days
            function weather_few_days() {
              console.log('weather_few_days()');
              let weatherData = weatherSensor.getForecastWeather();
              let forecastData = weatherData.forecastData;
              let result = {graphScale: 1, maximal_temp: 0};
              let maxOldX = 0;
              let minOldX = 0;

              if (screenType == hmSetting.screen_type.WATCHFACE) result = graphScale(15, 6, 6, forecastData.data, 3);
              let forecastGraphScale = result.graphScale;
              let maximal_temp = result.maximal_temp;
              console.log(`forecastGraphScale = ${forecastGraphScale}, maximal_temp = ${maximal_temp}`);

              if (screenType == hmSetting.screen_type.WATCHFACE) {
                normal_canvas1.clear({x: 0, y:0, w: 0, h: 0});
                normal_canvas2.clear({x: 0, y:0, w: 480, h: 480});
              };
              let normal_max_offsetX = 12;
              if (screenType == hmSetting.screen_type.WATCHFACE)  maxOldX = normal_max_offsetX;
              let maxOldY = (maximal_temp - forecastData.data[0].high) * forecastGraphScale + 3;
              let endPointMax = false;
              let normal_min_offsetX = 12;
              if (screenType == hmSetting.screen_type.WATCHFACE) minOldX = normal_min_offsetX;
              let minOldY = (maximal_temp - forecastData.data[0].low) * forecastGraphScale + 3;
              let endPointMin = false;
              for (let i = 0; i < 3; i++) {
                // Graph
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (i < forecastData.count) {
                    let maxStartX = maxOldX;
                    let maxStartY = maxOldY;
                    maxOldX = normal_max_offsetX + i * 30;
                    maxOldY = (maximal_temp - forecastData.data[i].high) * forecastGraphScale + 3;
                    let maxEndX = maxOldX;
                    let maxEndY = maxOldY;
                    if (maxStartX != maxEndX) {
                      drawLine(normal_canvas1, normal_canvas2, maxStartX, maxStartY, maxEndX, maxEndY, 0xFFFF0000, 2)
                      drawGraphPoint(normal_canvas1, normal_canvas2, maxStartX, maxStartY, 0xFFFF0000, 6, 3)
                      endPointMax = true;
                    };
                  
                    let minStartX = minOldX;
                    let minStartY = minOldY;
                    minOldX = normal_min_offsetX + i * 30;
                    minOldY = (maximal_temp - forecastData.data[i].low) * forecastGraphScale + 3;
                    let minEndX = minOldX;
                    let minEndY = minOldY;
                    if (minStartX != minEndX) {
                      drawLine(normal_canvas1, normal_canvas2, minStartX, minStartY, minEndX, minEndY, 0xFF9CFFFF, 2)
                      drawGraphPoint(normal_canvas1, normal_canvas2, minStartX, minStartY, 0xFF9CFFFF, 6, 3)
                      endPointMin = true;
                    };
                  
                  };
                };  // end screen_type
                
                // DayOfWeek font
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  let dowIndex = timeSensor.week - 1;
                  dowIndex += i;
                  while (dowIndex >= 7) {dowIndex -= 7;}
                  normal_forecast_date_week_font[i].setProperty(hmUI.prop.TEXT, normal_forecast_date_week_font_Array[dowIndex]);
                  if (dowIndex >= 5) normal_forecast_date_week_font[i].setProperty(hmUI.prop.COLOR, 0xFFFF0000);
                  else normal_forecast_date_week_font[i].setProperty(hmUI.prop.COLOR, 0xFFFFFFFF);
                };
              
                // Number_Font_Min
                let minTemperature = '-';
                if (i < forecastData.count) minTemperature = forecastData.data[i].low.toString();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  let normal_forecast_low_text_font_posY = (maximal_temp - forecastData.data[i].low) * forecastGraphScale + 3;
                  normal_forecast_low_text_font[i].setProperty(hmUI.prop.Y, normal_forecast_low_text_font_posY);
                  normal_forecast_low_text_font[i].setProperty(hmUI.prop.TEXT, minTemperature + '°');
                };
                
                // Number_Font_Max
                let maxTemperature = '-';
                if (i < forecastData.count) maxTemperature = forecastData.data[i].high.toString();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  let normal_forecast_high_text_font_posY = (maximal_temp - forecastData.data[i].high) * forecastGraphScale + -18;
                  normal_forecast_high_text_font[i].setProperty(hmUI.prop.Y, normal_forecast_high_text_font_posY);
                  normal_forecast_high_text_font[i].setProperty(hmUI.prop.TEXT, maxTemperature + '°');
                };
                
              };  // end for

              if (screenType == hmSetting.screen_type.WATCHFACE && endPointMax) {
                drawGraphPoint(normal_canvas1, normal_canvas2, maxOldX, maxOldY, 0xFFFF0000, 6, 3)
              };
              if (screenType == hmSetting.screen_type.WATCHFACE && endPointMin) {
                drawGraphPoint(normal_canvas1, normal_canvas2, minOldX, minOldY, 0xFF9CFFFF, 6, 3)
              };
            };
            //#endregion

            //#region compass_update
            console.log('compass_update()');
            if (screenType == hmSetting.screen_type.WATCHFACE){
              compass = hmSensor.createSensor(hmSensor.id.COMPASS);
              compass.start();

              if (compass.direction_angle && compass.direction  && compass.direction_angle != 'INVALID') { // initial data
                // Compass Pointer
                let compass_direction_angle = parseInt(compass.direction_angle);
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);
                // Compass Font
                let normal_compass_direction_angle_font = compass_direction_angle.toString();
                let compass_font_unit = '°';
                normal_compass_direction_angle_font += compass_font_unit;
                normal_compass_text_font.setProperty(hmUI.prop.TEXT, normal_compass_direction_angle_font);
                // Compass Images
                let compass_direction_angle_img = compass_direction_angle + 45 / 2;
                let compass_direction_index = parseInt(compass_direction_angle_img/45);
                if (compass_direction_index > 7) compass_direction_index = 0;
                normal_compass_direction_img_level.setProperty(hmUI.prop.SRC, normal_compass_direction_arr[compass_direction_index]);

              } else { // error data
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);
                normal_compass_text_font.setProperty(hmUI.prop.TEXT, '-');
                normal_compass_direction_img_level.setProperty(hmUI.prop.SRC, normal_compass_direction_arr[0]);

              }

              compass.addEventListener(hmSensor.event.CHANGE, function (compass_res) { // change values when changing direction

                if (compass_res.calibration_status) {
                  // Compass Pointer
                  let compass_direction_angle = parseInt(compass_res.direction_angle);
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);
                  // Compass Font
                  let normal_compass_direction_angle_font = compass_direction_angle.toString();
                  let compass_font_unit = '°';
                  normal_compass_direction_angle_font += compass_font_unit;
                  normal_compass_text_font.setProperty(hmUI.prop.TEXT, normal_compass_direction_angle_font);
                  // Compass Images
                  let compass_direction_angle_img = compass_direction_angle + 45 / 2;
                  let compass_direction_index = parseInt(compass_direction_angle_img/45);
                  if (compass_direction_index > 7) compass_direction_index = 0;
                  normal_compass_direction_img_level.setProperty(hmUI.prop.SRC, normal_compass_direction_arr[compass_direction_index]);

                } else { // error data
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);
                  normal_compass_text_font.setProperty(hmUI.prop.TEXT, '-');
                  normal_compass_direction_img_level.setProperty(hmUI.prop.SRC, normal_compass_direction_arr[0]);

                }

              }); // Listener end

            };
            //#endregion

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                if (compass && screenType == hmSetting.screen_type.WATCHFACE) compass.start();
                checkConnection();
                stopVibro();

                console.log('resume_call.js');
                // start resume_call.js

evo_resume();

                // end resume_call.js

                weather_few_days();
              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (compass) compass.stop();
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}