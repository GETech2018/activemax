﻿    /*
    ** Watch_Face_Editor tool v 18.0
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

// for vibration feedback
const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
let timer_StopVibrate = null;

function makeVibrate(level = 1) {
  let stopDelay = 50;
  stopVibrate();
  
  // after oct 23 update im gonna use increasing levels, where 1 is the lowest (for buttons),
  // 2 is mid level (for open settings) and 3 is the highest (for closing settings).
  const levelToScene = {
    1: 26,
    2: 27,
    3: 29
  };

  let scene = levelToScene[level] || 25;
  vibrate.scene = scene;
  if (scene > 25) stopDelay = 1300;
  vibrate.start();
  timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibrate, {});
}

function stopVibrate() {
  vibrate.stop();
  if (timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
}

//////Watchface Language Sets (Uppercase)
const watchfaceLangs = {
  EN:{
    WEEKDAYS_SHORT: ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"],
  },

  ES:{
    WEEKDAYS_SHORT: ["LUN", "MAR", "MIÉ", "JUE", "VIE", "SÁB", "DOM"],
  },

  PT:{
    WEEKDAYS_SHORT: ["SEG", "TER", "QUA", "QUI", "SEX", "SÁB", "DOM"],
  },

  FR:{
    WEEKDAYS_SHORT: ["LUN", "MAR", "MER", "JEU", "VEN", "SAM", "DIM"],
  },

  RU:{
    WEEKDAYS_SHORT: ["ПН", "ВТ", "СР", "ЧТ", "ПТ", "СБ", "ВС"],
  },
};
let currWatchfaceLang;
let currLangCode;

const colorsSet = [
    "BLUE",
    "CYAN",
    "TURQUOISE",
    "LIME",
    "GREEN",
    "YELLOW",
    "ORANGE",
    "RED",
    "PINK",
    "VIOLET",
    "GRAY",
    "WHITE",
];

const colorHEXset = [
    0xFF74C0FC, // Blue
    0xFF66E6FF, // Cyan
    0xFF63E6BE, // Turquoise
    0xFFAEE66D, // Lime
    0xFF8BE78B, // Green
    0xFFFFEB66, // Yellow
    0xFFFFA94D, // Orange
    0xFFFF6B6B, // Red
    0xFFF58AB5, // Pink
    0xFFA68AD9, // Violet
    0xFFC1C9E5, // Gray
    0xFFFFFFFF, // White
];

let colorIndex = 0;
let currColorFolder = "sets/" + colorsSet[colorIndex] + "/";
let currHEXColor = colorHEXset[colorIndex];

//Variables for clock format
let isClockWithSeconds = false;
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let normal_frame_animation_1 = ''
        let normal_weather_image_progress_img_level = ''
        let idle_background_bg = ''
        let idle_image_img = ''
        let idle_digital_clock_img_time = ''
        let idle_date_img_date_day = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('user_script_start.js');
            // start user_script_start.js

//////Function to detect current language from system
function detectLanguage() {
    const zeppAvailableLangs = [
        "ZH", // 0  Chinese (Simplified)
        "ZH", // 1  Chinese (Traditional)
        "EN", // 2  English
        "ES", // 3  Spanish
        "RU", // 4  Russian
        "KO", // 5  Korean
        "FR", // 6  French
        "DE", // 7  German
        "ID", // 8  Indonesian
        "PL", // 9  Polish
        "IT", // 10 Italian
        "JA", // 11 Japanese
        "TH", // 12 Thai
        "AR", // 13 Arabic
        "VI", // 14 Vietnamese
        "PT", // 15 Portuguese (Portugal)
        "NL", // 16 Dutch
        "TR", // 17 Turkish
        "UK", // 18 Ukrainian
        "HE", // 19 Hebrew
        "PT", // 20 Portuguese (Brazil)
        "RO", // 21 Romanian
        "CS", // 22 Czech
        "EL", // 23 Greek
        "SR", // 24 Serbian
        "CA", // 25 Catalan
        "FI", // 26 Finnish
        "NO", // 27 Norwegian
        "DA", // 28 Danish
        "SV", // 29 Swedish
        "HU", // 30 Hungarian
        "MS", // 31 Malay
        "SK", // 32 Slovak
        "HI"  // 33 Hindi
    ];
    let langCode = zeppAvailableLangs[hmSetting.getLanguage()]; //Get current language on watch

    currLangCode = watchfaceLangs[langCode] ? langCode : "EN";
    currWatchfaceLang = watchfaceLangs[currLangCode];
}
detectLanguage();

let bgColor = hmUI.createWidget(hmUI.widget.FILL_RECT, {
    x: 0,
    y: 0,
    w: 480,
    h: 480,
    color: 0xFF74C0FC,
    show_level: hmUI.show_level.ONLY_NORMAL
});

let bgBottom = hmUI.createWidget(hmUI.widget.IMG, {
    x: 0,
    y: 0,
    src: "background/bottom/BOTTOM_" + currLangCode + ".png",
    show_level: hmUI.show_level.ONLY_NORMAL
});

let bgTop = hmUI.createWidget(hmUI.widget.IMG, {
    x: 0,
    y: 0,
    src: "background/top/" + (currLangCode !== "RU" ? "TOP_NOSECS_NORUSSIAN.png" : "TOP_NOSECS_RUSSIAN.png"),
    show_level: hmUI.show_level.ONLY_NORMAL
});
            // end user_script_start.js

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'TRANSPARENT.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 283,
              day_startY: 60,
              day_sc_array: ["DATA_0.png","DATA_1.png","DATA_2.png","DATA_3.png","DATA_4.png","DATA_5.png","DATA_6.png","DATA_7.png","DATA_8.png","DATA_9.png"],
              day_tc_array: ["DATA_0.png","DATA_1.png","DATA_2.png","DATA_3.png","DATA_4.png","DATA_5.png","DATA_6.png","DATA_7.png","DATA_8.png","DATA_9.png"],
              day_en_array: ["DATA_0.png","DATA_1.png","DATA_2.png","DATA_3.png","DATA_4.png","DATA_5.png","DATA_6.png","DATA_7.png","DATA_8.png","DATA_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 43,
              hour_startY: 142,
              hour_array: ["CLOCK_0.png","CLOCK_1.png","CLOCK_2.png","CLOCK_3.png","CLOCK_4.png","CLOCK_5.png","CLOCK_6.png","CLOCK_7.png","CLOCK_8.png","CLOCK_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 184,
              minute_startY: 142,
              minute_array: ["CLOCK_0.png","CLOCK_1.png","CLOCK_2.png","CLOCK_3.png","CLOCK_4.png","CLOCK_5.png","CLOCK_6.png","CLOCK_7.png","CLOCK_8.png","CLOCK_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 167,
              y: 162,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "CLOCK_SEPARATOR",
              anim_fps: 2,
              anim_size: 2,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 105,
              y: 354,
              image_array: ["WEATHERICON_1.png","WEATHERICON_2.png","WEATHERICON_3.png","WEATHERICON_4.png","WEATHERICON_5.png","WEATHERICON_6.png","WEATHERICON_7.png","WEATHERICON_8.png","WEATHERICON_9.png","WEATHERICON_10.png","WEATHERICON_11.png","WEATHERICON_12.png","WEATHERICON_13.png","WEATHERICON_14.png","WEATHERICON_15.png","WEATHERICON_16.png","WEATHERICON_17.png","WEATHERICON_18.png","WEATHERICON_19.png","WEATHERICON_20.png","WEATHERICON_21.png","WEATHERICON_22.png","WEATHERICON_23.png","WEATHERICON_24.png","WEATHERICON_25.png","WEATHERICON_26.png","WEATHERICON_27.png","WEATHERICON_28.png","WEATHERICON_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script.js');
            // start user_script.js
let normalClockWithSecsDigits = hmUI.createWidget(hmUI.widget.IMG_TIME, {
    hour_startX: 37,
    hour_startY: 142,
    hour_array: ["CLOCK_0.png","CLOCK_1.png","CLOCK_2.png","CLOCK_3.png","CLOCK_4.png","CLOCK_5.png","CLOCK_6.png","CLOCK_7.png","CLOCK_8.png","CLOCK_9.png"],
    hour_zero: 1,
    hour_space: 0,
    hour_angle: 0,
    hour_align: hmUI.align.LEFT,

    minute_startX: 178,
    minute_startY: 142,
    minute_array: ["CLOCK_0.png","CLOCK_1.png","CLOCK_2.png","CLOCK_3.png","CLOCK_4.png","CLOCK_5.png","CLOCK_6.png","CLOCK_7.png","CLOCK_8.png","CLOCK_9.png"],
    minute_zero: 1,
    minute_space: 0,
    minute_angle: 0,
    minute_follow: 0,
    minute_align: hmUI.align.LEFT,

    second_startX: 319,
    second_startY: 142,
    second_array: ["CLOCK_0.png","CLOCK_1.png","CLOCK_2.png","CLOCK_3.png","CLOCK_4.png","CLOCK_5.png","CLOCK_6.png","CLOCK_7.png","CLOCK_8.png","CLOCK_9.png"],
    second_zero: 1,
    second_space: 0,
    second_angle: 0,
    second_follow: 0,
    second_align: hmUI.align.LEFT,

    show_level: hmUI.show_level.ONLY_NORMAL,
});
normalClockWithSecsDigits.setProperty(hmUI.prop.VISIBLE, false);

let WeekDaysIMG = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
    x: 111,
    y: 60,
    week_en: ["DAYS_" + currLangCode + "_01.png","DAYS_" + currLangCode + "_02.png","DAYS_" + currLangCode + "_03.png","DAYS_" + currLangCode + "_04.png","DAYS_" + currLangCode + "_05.png","DAYS_" + currLangCode + "_06.png","DAYS_" + currLangCode + "_07.png"],
    week_tc: ["DAYS_" + currLangCode + "_01.png","DAYS_" + currLangCode + "_02.png","DAYS_" + currLangCode + "_03.png","DAYS_" + currLangCode + "_04.png","DAYS_" + currLangCode + "_05.png","DAYS_" + currLangCode + "_06.png","DAYS_" + currLangCode + "_07.png"],
    week_sc: ["DAYS_" + currLangCode + "_01.png","DAYS_" + currLangCode + "_02.png","DAYS_" + currLangCode + "_03.png","DAYS_" + currLangCode + "_04.png","DAYS_" + currLangCode + "_05.png","DAYS_" + currLangCode + "_06.png","DAYS_" + currLangCode + "_07.png"],
    show_level: hmUI.show_level.ONLY_NORMAL,
});

let weatherTemp = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
    x: 203,
    y: 362,
    font_array: [currColorFolder + "DATA_0.png", currColorFolder + "DATA_1.png", currColorFolder + "DATA_2.png", currColorFolder + "DATA_3.png", currColorFolder + "DATA_4.png", currColorFolder + "DATA_5.png", currColorFolder + "DATA_6.png", currColorFolder + "DATA_7.png", currColorFolder + "DATA_8.png", currColorFolder + "DATA_9.png"],
    padding: false,
    h_space: 0,
    unit_sc: currColorFolder + 'DEGREE.png',
    unit_tc: currColorFolder + 'DEGREE.png',
    unit_en: currColorFolder + 'DEGREE.png',
    imperial_unit_sc: currColorFolder + 'DEGREE.png',
    imperial_unit_tc: currColorFolder + 'DEGREE.png',
    imperial_unit_en: currColorFolder + 'DEGREE.png',
    negative_image: currColorFolder + 'DATA_NEGATIVE.png',
    invalid_image: currColorFolder + 'DATA_NODATA.png',
    align_h: hmUI.align.RIGHT,
    type: hmUI.data_type.WEATHER_CURRENT,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

let stepsDigits = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
    x: 47,
    y: 270,
    font_array: [currColorFolder + "DATA_0.png", currColorFolder + "DATA_1.png", currColorFolder + "DATA_2.png", currColorFolder + "DATA_3.png", currColorFolder + "DATA_4.png", currColorFolder + "DATA_5.png", currColorFolder + "DATA_6.png", currColorFolder + "DATA_7.png", currColorFolder + "DATA_8.png", currColorFolder + "DATA_9.png"],
    padding: false,
    h_space: 0,
    align_h: hmUI.align.RIGHT,
    type: hmUI.data_type.STEP,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

let hrmDigits = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
    x: 305,
    y: 270,
    font_array: [currColorFolder + "DATA_0.png", currColorFolder + "DATA_1.png", currColorFolder + "DATA_2.png", currColorFolder + "DATA_3.png", currColorFolder + "DATA_4.png", currColorFolder + "DATA_5.png", currColorFolder + "DATA_6.png", currColorFolder + "DATA_7.png", currColorFolder + "DATA_8.png", currColorFolder + "DATA_9.png"],
    padding: false,
    h_space: 0,
    align_h: hmUI.align.RIGHT,
    type: hmUI.data_type.HEART,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

//Battery graph
const battery = hmSensor.createSensor(hmSensor.id.BATTERY);

let batteryGraph = hmUI.createWidget(hmUI.widget.IMG, {
    x: 348,
    y: 168,
    src: "graphs/GRAPHS_1.png",
    show_level: hmUI.show_level.ONLY_NORMAL,
});

function updateBatteryGraph(){
    let currBatteryLevel = battery.current;
    let batteryIndex = currBatteryLevel >= 90 ? 5 : Math.max(1, Math.ceil(currBatteryLevel / 20));

    let currBatteryLevelIMG = "graphs/GRAPHS_" + batteryIndex + ".png";
    batteryGraph.setProperty(hmUI.prop.SRC, currBatteryLevelIMG);
}
updateBatteryGraph();

battery.addEventListener(hmSensor.event.CHANGE, function () {
    updateBatteryGraph();
});
            // end user_script.js


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'BG_AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 37,
              hour_startY: 142,
              hour_array: ["CLOCK_0.png","CLOCK_1.png","CLOCK_2.png","CLOCK_3.png","CLOCK_4.png","CLOCK_5.png","CLOCK_6.png","CLOCK_7.png","CLOCK_8.png","CLOCK_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 178,
              minute_startY: 142,
              minute_array: ["CLOCK_0.png","CLOCK_1.png","CLOCK_2.png","CLOCK_3.png","CLOCK_4.png","CLOCK_5.png","CLOCK_6.png","CLOCK_7.png","CLOCK_8.png","CLOCK_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 319,
              second_startY: 142,
              second_array: ["CLOCK_0.png","CLOCK_1.png","CLOCK_2.png","CLOCK_3.png","CLOCK_4.png","CLOCK_5.png","CLOCK_6.png","CLOCK_7.png","CLOCK_8.png","CLOCK_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 283,
              day_startY: 60,
              day_sc_array: ["DATA_0.png","DATA_1.png","DATA_2.png","DATA_3.png","DATA_4.png","DATA_5.png","DATA_6.png","DATA_7.png","DATA_8.png","DATA_9.png"],
              day_tc_array: ["DATA_0.png","DATA_1.png","DATA_2.png","DATA_3.png","DATA_4.png","DATA_5.png","DATA_6.png","DATA_7.png","DATA_8.png","DATA_9.png"],
              day_en_array: ["DATA_0.png","DATA_1.png","DATA_2.png","DATA_3.png","DATA_4.png","DATA_5.png","DATA_6.png","DATA_7.png","DATA_8.png","DATA_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('user_script_beforeShortcuts.js');
            // start user_script_beforeShortcuts.js

let idle_dayOfWeek = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
    x: 111,
    y: 60,
    week_en: ["DAYS_" + currLangCode + "_01.png","DAYS_" + currLangCode + "_02.png","DAYS_" + currLangCode + "_03.png","DAYS_" + currLangCode + "_04.png","DAYS_" + currLangCode + "_05.png","DAYS_" + currLangCode + "_06.png","DAYS_" + currLangCode + "_07.png"],
    week_tc: ["DAYS_" + currLangCode + "_01.png","DAYS_" + currLangCode + "_02.png","DAYS_" + currLangCode + "_03.png","DAYS_" + currLangCode + "_04.png","DAYS_" + currLangCode + "_05.png","DAYS_" + currLangCode + "_06.png","DAYS_" + currLangCode + "_07.png"],
    week_sc: ["DAYS_" + currLangCode + "_01.png","DAYS_" + currLangCode + "_02.png","DAYS_" + currLangCode + "_03.png","DAYS_" + currLangCode + "_04.png","DAYS_" + currLangCode + "_05.png","DAYS_" + currLangCode + "_06.png","DAYS_" + currLangCode + "_07.png"],
    show_level: hmUI.show_level.ONLY_AOD,
});
            // end user_script_beforeShortcuts.js

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 103,
              y: 50,
              w: 280,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                settingsMenu(true)
makeVibrate(2)
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 40,
              y: 145,
              w: 130,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 185,
              y: 145,
              w: 130,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 324,
              y: 145,
              w: 130,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 324,
              y: 145,
              w: 130,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_batteryManagerScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 55,
              y: 260,
              w: 220,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 300,
              y: 260,
              w: 150,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 125,
              y: 350,
              w: 250,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

//Hide countdown shortcut by default
Button_4.setProperty(hmUI.prop.VISIBLE, false);

let prevColorbtn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 0,
    y: 49,
    w: 134,
    h: 382,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'settings/BTNPREV_PRESSED.png',
    normal_src: 'settings/BTNPREV_NORMAL.png',
    click_func: (button_widget) => {
    prevColor()
    makeVibrate(1)
    }, // end func
    show_level: hmUI.show_level.ONLY_NORMAL,
}); // end button

let nextColorbtn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 346,
    y: 49,
    w: 134,
    h: 382,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'settings/BTNNEXT_PRESSED.png',
    normal_src: 'settings/BTNNEXT_NORMAL.png',
    click_func: (button_widget) => {
    nextColor()
    makeVibrate(1)
    }, // end func
    show_level: hmUI.show_level.ONLY_NORMAL,
}); // end button

let changeClockFormatbtn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 100,
    y: 133,
    w: 280,
    h: 100,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'BUTTON.png',
    normal_src: 'BUTTON.png',
    click_func: (button_widget) => {
    changeClockFormat()
    makeVibrate(1)
    }, // end func
    show_level: hmUI.show_level.ONLY_NORMAL,
}); // end button

let Confirmbtn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 180,
    y: 350,
    w: 120,
    h: 90,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'settings/BTN_CONFIRM_PRESSED.png',
    normal_src: 'settings/BTN_CONFIRM_NORMAL.png',
    click_func: (button_widget) => {
    settingsMenu(false)
    makeVibrate(3)
    }, // end func
    show_level: hmUI.show_level.ONLY_NORMAL,
}); // end button

function prevColor(){
    colorIndex = (colorIndex - 1 + colorsSet.length) % colorsSet.length;
    updateWatchface();
}

function nextColor(){
    colorIndex = (colorIndex + 1) % colorsSet.length;
    updateWatchface();
}

function changeClockFormat(){
    isClockWithSeconds = !isClockWithSeconds;
    updateWatchface();
}

function updateWatchface(){
    let currClockSeparator_xPos;
    let currTopPartStyle;
    let currBGAODStyle;
    let currBatteryButton_yPos;

    currColorFolder = "sets/" + colorsSet[colorIndex] + "/";
    currHEXColor = colorHEXset[colorIndex];

    bgColor.setProperty(hmUI.prop.COLOR, currHEXColor);

    if (isClockWithSeconds){
        currClockSeparator_xPos = 302;
        
        currTopPartStyle = "background/top/TOP_WITHSECS.png";
        currBGAODStyle = "BG_AOD_WITHSECS.png";
        currBatteryButton_yPos = 154;
    }else{
        currClockSeparator_xPos = 167;

        currTopPartStyle = "background/top/" + (currLangCode !== "RU" ? "TOP_NOSECS_NORUSSIAN.png" : "TOP_NOSECS_RUSSIAN.png");
        currBGAODStyle = "BG_AOD_NOSECS.png";
        currBatteryButton_yPos = 62;
    }

    //Set top part background
    bgTop.setProperty(hmUI.prop.SRC, currTopPartStyle);

    ///Set new clock format
    normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, !isClockWithSeconds);
    normalClockWithSecsDigits.setProperty(hmUI.prop.VISIBLE, isClockWithSeconds);
    normal_frame_animation_1.setProperty(hmUI.prop.X, currClockSeparator_xPos);

    //Set graphs and buttons
    batteryGraph.setProperty(hmUI.prop.VISIBLE, !isClockWithSeconds);
    Button_5.setProperty(hmUI.prop.VISIBLE, !isClockWithSeconds);
    Button_4.setProperty(hmUI.prop.VISIBLE, isClockWithSeconds);

    weatherTemp.setProperty(hmUI.prop.MORE, {
        x: 203,
        y: 362,
        font_array: [currColorFolder + "DATA_0.png", currColorFolder + "DATA_1.png", currColorFolder + "DATA_2.png", currColorFolder + "DATA_3.png", currColorFolder + "DATA_4.png", currColorFolder + "DATA_5.png", currColorFolder + "DATA_6.png", currColorFolder + "DATA_7.png", currColorFolder + "DATA_8.png", currColorFolder + "DATA_9.png"],
        padding: false,
        h_space: 0,
        unit_sc: currColorFolder + 'DEGREE.png',
        unit_tc: currColorFolder + 'DEGREE.png',
        unit_en: currColorFolder + 'DEGREE.png',
        imperial_unit_sc: currColorFolder + 'DEGREE.png',
        imperial_unit_tc: currColorFolder + 'DEGREE.png',
        imperial_unit_en: currColorFolder + 'DEGREE.png',
        negative_image: currColorFolder + 'DATA_NEGATIVE.png',
        invalid_image: currColorFolder + 'DATA_NODATA.png',
        align_h: hmUI.align.RIGHT,
        type: hmUI.data_type.WEATHER_CURRENT,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    stepsDigits.setProperty(hmUI.prop.MORE, {
        x: 47,
        y: 270,
        font_array: [currColorFolder + "DATA_0.png", currColorFolder + "DATA_1.png", currColorFolder + "DATA_2.png", currColorFolder + "DATA_3.png", currColorFolder + "DATA_4.png", currColorFolder + "DATA_5.png", currColorFolder + "DATA_6.png", currColorFolder + "DATA_7.png", currColorFolder + "DATA_8.png", currColorFolder + "DATA_9.png"],
        padding: false,
        h_space: 0,
        align_h: hmUI.align.RIGHT,
        type: hmUI.data_type.STEP,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    hrmDigits.setProperty(hmUI.prop.MORE, {
        x: 305,
        y: 270,
        font_array: [currColorFolder + "DATA_0.png", currColorFolder + "DATA_1.png", currColorFolder + "DATA_2.png", currColorFolder + "DATA_3.png", currColorFolder + "DATA_4.png", currColorFolder + "DATA_5.png", currColorFolder + "DATA_6.png", currColorFolder + "DATA_7.png", currColorFolder + "DATA_8.png", currColorFolder + "DATA_9.png"],
        padding: false,
        h_space: 0,
        align_h: hmUI.align.RIGHT,
        type: hmUI.data_type.HEART,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    hmFS.SysProSetInt('DottedClock_colorIndexAOD', currHEXColor);
}

let watchfaceButtons = [ Button_1 ];
let settingMenuLayout = [ prevColorbtn, nextColorbtn, changeClockFormatbtn, Confirmbtn ];

function settingsMenu(isVisible){
    watchfaceButtons.forEach(element => element.setProperty(hmUI.prop.VISIBLE, !isVisible));
    Button_5.setProperty(hmUI.prop.VISIBLE, !isClockWithSeconds);
    Button_4.setProperty(hmUI.prop.VISIBLE, isClockWithSeconds);
    
    settingMenuLayout.forEach(element => element.setProperty(hmUI.prop.VISIBLE, isVisible));
};
settingsMenu(false);

idle_background_bg.setProperty(hmUI.prop.COLOR, hmFS.SysProGetInt('DottedClock_colorIndexAOD') ?? 0xFF74C0FC);
            // end user_script_end.js

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);

                console.log('resume_call.js');
                // start resume_call.js

updateBatteryGraph()
                // end resume_call.js

              }),
              pause_call: (function () {
                console.log('pause_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);

                console.log('pause_call.js');
                // start pause_call.js

settingsMenu(false);
                // end pause_call.js

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}