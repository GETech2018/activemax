﻿    /*
    ** Watch_Face_Editor tool v 18.1
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

//////Vibration feedback for buttons
const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
let timer_StopVibrate = null;

function makeVibrate(level = 1) {
  stopVibrate();

  //The values are used as follows: 1 for buttons, 2 for open settings menu, 3 for close settings menu
  const levelToScene = {
    1: 26,
    2: 27,
    3: 29
  };

  let scene = levelToScene[level] || 25;
  let stopDelay = scene > 25 ? 1300 : 50;

  vibrate.scene = scene;
  vibrate.start();

  timer_StopVibrate = timer.createTimer(stopDelay, 0, stopVibrate, {});
}

function stopVibrate() {
  vibrate.stop();
  if (timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
  timer_StopVibrate = null;
}

//////Watchface Language Sets (Uppercase)
const watchfaceLangs = {
  EN:{
    WEEKDAYS_SHORT: ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"],
    WEEKDAYS_FULL:  ["MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY", "SUNDAY"],
    MONTHS_SHORT:   ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"],
    MONTHS_FULL:    ["JANUARY", "FEBRUARY", "MARCH", "APRIL", "MAY", "JUNE", "JULY", "AUGUST", "SEPTEMBER", "OCTOBER", "NOVEMBER", "DECEMBER"],

    STEPSLABEL: "STEPS",
    BATTERYLABEL: "BATTERY",
    HEARTRATELABEL: "BPM",
    CALORIESLABEL: "CALORIES",
  },

  ES:{
    WEEKDAYS_SHORT: ["LUN", "MAR", "MIÉ", "JUE", "VIE", "SÁB", "DOM"],
    WEEKDAYS_FULL:  ["LUNES", "MARTES", "MIÉRCOLES", "JUEVES", "VIERNES", "SÁBADO", "DOMINGO"],
    MONTHS_SHORT:   ["ENE", "FEB", "MAR", "ABR", "MAY", "JUN", "JUL", "AGO", "SEP", "OCT", "NOV", "DIC"],
    MONTHS_FULL:    ["ENERO", "FEBRERO", "MARZO", "ABRIL", "MAYO", "JUNIO", "JULIO", "AGOSTO", "SEPTIEMBRE", "OCTUBRE", "NOVIEMBRE", "DICIEMBRE"],

    STEPSLABEL: "PASOS",
    BATTERYLABEL: "BATERÍA",
    HEARTRATELABEL: "BPM",
    CALORIESLABEL: "CALORÍAS",
  },

  IT:{
    WEEKDAYS_SHORT: ["LUN", "MAR", "MER", "GIO", "VEN", "SAB", "DOM"],
    WEEKDAYS_FULL:  ["LUNEDÌ", "MARTEDÌ", "MERCOLEDÌ", "GIOVEDÌ", "VENERDÌ", "SABATO", "DOMENICA"],
    MONTHS_SHORT:   ["GEN", "FEB", "MAR", "APR", "MAG", "GIU", "LUG", "AGO", "SET", "OTT", "NOV", "DIC"],
    MONTHS_FULL:    ["GENNAIO", "FEBBRAIO", "MARZO", "APRILE", "MAGGIO", "GIUGNO", "LUGLIO", "AGOSTO", "SETTEMBRE", "OTTOBRE", "NOVEMBRE", "DICEMBRE"],

    STEPSLABEL: "PASSI",
    BATTERYLABEL: "BATTERIA",
    HEARTRATELABEL: "BPM",
    CALORIESLABEL: "CALORIE",
  },

  PT:{
    WEEKDAYS_SHORT: ["SEG", "TER", "QUA", "QUI", "SEX", "SÁB", "DOM"],
    WEEKDAYS_FULL:  ["SEGUNDA-FEIRA", "TERÇA-FEIRA", "QUARTA-FEIRA", "QUINTA-FEIRA", "SEXTA-FEIRA", "SÁBADO", "DOMINGO"],
    MONTHS_SHORT:   ["JAN", "FEV", "MAR", "ABR", "MAI", "JUN", "JUL", "AGO", "SET", "OUT", "NOV", "DEZ"],
    MONTHS_FULL:    ["JANEIRO", "FEVEREIRO", "MARÇO", "ABRIL", "MAIO", "JUNHO", "JULHO", "AGOSTO", "SETEMBRO", "OUTUBRO", "NOVEMBRO", "DEZEMBRO"],

    STEPSLABEL: "PASSOS",
    BATTERYLABEL: "BATERIA",
    HEARTRATELABEL: "BPM",
    CALORIESLABEL: "CALORIAS",
  },

  FR:{
    WEEKDAYS_SHORT: ["LUN", "MAR", "MER", "JEU", "VEN", "SAM", "DIM"],
    WEEKDAYS_FULL:  ["LUNDI", "MARDI", "MERCREDI", "JEUDI", "VENDREDI", "SAMEDI", "DIMANCHE"],
    MONTHS_SHORT:   ["JAN", "FÉV", "MAR", "AVR", "MAI", "JUN", "JUI", "AOÛ", "SEP", "OCT", "NOV", "DÉC"],
    MONTHS_FULL:    ["JANVIER", "FÉVRIER", "MARS", "AVRIL", "MAI", "JUIN", "JUILLET", "AOÛT", "SEPTEMBRE", "OCTOBRE", "NOVEMBRE", "DÉCEMBRE"],

    STEPSLABEL: "PAS",
    BATTERYLABEL: "BATTERIE",
    HEARTRATELABEL: "BPM",
    CALORIESLABEL: "CALORIES",
  },
  
  RU:{
    WEEKDAYS_SHORT: ["ПН", "ВТ", "СР", "ЧТ", "ПТ", "СБ", "ВС"],
    WEEKDAYS_FULL:  ["ПОНЕДЕЛЬНИК", "ВТОРНИК", "СРЕДА", "ЧЕТВЕРГ", "ПЯТНИЦА", "СУББОТА", "ВОСКРЕСЕНЬЕ"],
    MONTHS_SHORT:   ["ЯНВ", "ФЕВ", "МАР", "АПР", "МАЙ", "ИЮН", "ИЮЛ", "АВГ", "СЕН", "ОКТ", "НОЯ", "ДЕК"],
    MONTHS_FULL:    ["ЯНВАРЬ", "ФЕВРАЛЬ", "МАРТ", "АПРЕЛЬ", "МАЙ", "ИЮНЬ", "ИЮЛЬ", "АВГУСТ", "СЕНТЯБРЬ", "ОКТЯБРЬ", "НОЯБРЬ", "ДЕКАБРЬ"],

    STEPSLABEL: "ШАГИ",
    BATTERYLABEL: "ЗАРЯД",
    HEARTRATELABEL: "ПУЛЬС",
    CALORIESLABEL: "КАЛОРИИ",
  },
};
let currWatchfaceLang;
let currLangCode;

let colorsSet = 10;
let colorIndex = 1;
let currHourFormat = hmSetting.getTimeFormat(); //Get time format 12h/24h
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_analog_clock_time_pointer_smooth_second = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_font = ''
        let normal_step_current_text_font = ''
        let normal_battery_current_text_font = ''
        let idle_background_bg_img = ''
        let idle_image_img = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: SF-Compact-Rounded-Bold.ttf; FontSize: 30; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 36,
              h: 36,
              text_size: 30,
              char_space: 6,
              line_space: 0,
              font: 'fonts/SF-Compact-Rounded-Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script_start.js');
            // start user_script_start.js

//////Function to detect current language from system
function detectLanguage() {
    const zeppAvailableLangs = [
        "ZH", // 0  Chinese (Simplified)
        "ZH", // 1  Chinese (Traditional)
        "EN", // 2  English
        "ES", // 3  Spanish
        "RU", // 4  Russian
        "KO", // 5  Korean
        "FR", // 6  French
        "DE", // 7  German
        "ID", // 8  Indonesian
        "PL", // 9  Polish
        "IT", // 10 Italian
        "JA", // 11 Japanese
        "TH", // 12 Thai
        "AR", // 13 Arabic
        "VI", // 14 Vietnamese
        "PT", // 15 Portuguese (Portugal)
        "NL", // 16 Dutch
        "TR", // 17 Turkish
        "UK", // 18 Ukrainian
        "HE", // 19 Hebrew
        "PT", // 20 Portuguese (Brazil)
        "RO", // 21 Romanian
        "CS", // 22 Czech
        "EL", // 23 Greek
        "SR", // 24 Serbian
        "CA", // 25 Catalan
        "FI", // 26 Finnish
        "NO", // 27 Norwegian
        "DA", // 28 Danish
        "SV", // 29 Swedish
        "HU", // 30 Hungarian
        "MS", // 31 Malay
        "SK", // 32 Slovak
        "HI"  // 33 Hindi
    ];
    let langCode = zeppAvailableLangs[hmSetting.getLanguage()]; //Get current language on watch

    currLangCode = watchfaceLangs[langCode] ? langCode : "EN";
    currWatchfaceLang = watchfaceLangs[currLangCode];
}
detectLanguage();
            // end user_script_start.js

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'BG_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'CLOCK_HAND_SEC_1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 142,
              // y: 212,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_time_pointer_smooth_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'CLOCK_HAND_SEC_1.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 142,
              second_posY: 212,
              fresh_frequency: 15,
              fresh_freqency: 15,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              let updateHour = timeSensor.minute == 0;

              time_update(updateHour, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'CLOCK_HAND_HRMIN_1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 40,
              // y: 200,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 40,
              pos_y: 240 - 200,
              center_x: 240,
              center_y: 240,
              src: 'CLOCK_HAND_HRMIN_1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'CLOCK_HAND_HRMIN_1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 40,
              // y: 200,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 40,
              pos_y: 240 - 200,
              center_x: 240,
              center_y: 240,
              src: 'CLOCK_HAND_HRMIN_1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 3,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 26,
              y: 26,
              w: 428,
              h: 428,
              text_size: 30,
              char_space: 6,
              font: 'fonts/SF-Compact-Rounded-Bold.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: -73,
              end_angle: 0,
              mode: 0,
              // radius: 214,
              align_h: hmUI.align.LEFT,
              // unit_string: MON, TUE, WED, THU, FRI, SAT, SUN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 290,
              y: 30,
              image_array: ["WEATHERICON_1.png","WEATHERICON_2.png","WEATHERICON_3.png","WEATHERICON_4.png","WEATHERICON_5.png","WEATHERICON_6.png","WEATHERICON_7.png","WEATHERICON_8.png","WEATHERICON_9.png","WEATHERICON_10.png","WEATHERICON_11.png","WEATHERICON_12.png","WEATHERICON_13.png","WEATHERICON_14.png","WEATHERICON_15.png","WEATHERICON_16.png","WEATHERICON_17.png","WEATHERICON_18.png","WEATHERICON_19.png","WEATHERICON_20.png","WEATHERICON_21.png","WEATHERICON_22.png","WEATHERICON_23.png","WEATHERICON_24.png","WEATHERICON_25.png","WEATHERICON_26.png","WEATHERICON_27.png","WEATHERICON_28.png","WEATHERICON_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 26,
              y: 26,
              w: 428,
              h: 428,
              text_size: 30,
              char_space: 6,
              font: 'fonts/SF-Compact-Rounded-Bold.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 34,
              end_angle: 70,
              mode: 0,
              // radius: 214,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 26,
              y: 26,
              w: 428,
              h: 428,
              text_size: 30,
              char_space: 6,
              font: 'fonts/SF-Compact-Rounded-Bold.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 80,
              end_angle: 132,
              mode: 1,
              // radius: 214,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 26,
              y: 26,
              w: 428,
              h: 428,
              text_size: 30,
              char_space: 6,
              font: 'fonts/SF-Compact-Rounded-Bold.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 180,
              end_angle: 221,
              mode: 1,
              // radius: 214,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'BG_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'AODOVERLAY.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('user_script_beforeShortcuts.js');
            // start user_script_beforeShortcuts.js

normal_weather_image_progress_img_level.setAlpha(128);

//////Clock digits
let clockDigitHrHigh_xPos = 154;
let clockDigitHrHigh_yPos = 133;

let clockDigitHrLow_xPos = 215;
let clockDigitHrLow_yPos = 133;

let clockDigitMinHigh_xPos = 162;
let clockDigitMinHigh_yPos = 211;

let clockDigitMinLow_xPos = 223;
let clockDigitMinLow_yPos = 211;

//Normal and AOD
let clockDigitMinLow = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
    x: clockDigitMinLow_xPos,
    y: clockDigitMinLow_yPos,
    font_array: ["CLOCKWHITE_0.png", "CLOCKWHITE_1.png", "CLOCKWHITE_2.png", "CLOCKWHITE_3.png", "CLOCKWHITE_4.png", "CLOCKWHITE_5.png", "CLOCKWHITE_6.png", "CLOCKWHITE_7.png", "CLOCKWHITE_8.png", "CLOCKWHITE_9.png"],
    padding: false,
    h_space: 0,
    text: "0",
    align_h: hmUI.align.LEFT,
    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
});
let clockDigitHrHigh = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
    x: clockDigitHrHigh_xPos,
    y: clockDigitHrHigh_yPos,
    font_array: ["CLOCKWHITE_0.png", "CLOCKWHITE_1.png", "CLOCKWHITE_2.png", "CLOCKWHITE_3.png", "CLOCKWHITE_4.png", "CLOCKWHITE_5.png", "CLOCKWHITE_6.png", "CLOCKWHITE_7.png", "CLOCKWHITE_8.png", "CLOCKWHITE_9.png"],
    padding: false,
    h_space: 0,
    text: "0",
    align_h: hmUI.align.LEFT,
    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
});
let clockDigitHrLow = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
    x: clockDigitHrLow_xPos,
    y: clockDigitHrLow_yPos,
    font_array: ["CLOCKWHITE_0.png", "CLOCKWHITE_1.png", "CLOCKWHITE_2.png", "CLOCKWHITE_3.png", "CLOCKWHITE_4.png", "CLOCKWHITE_5.png", "CLOCKWHITE_6.png", "CLOCKWHITE_7.png", "CLOCKWHITE_8.png", "CLOCKWHITE_9.png"],
    padding: false,
    h_space: 0,
    text: "0",
    align_h: hmUI.align.LEFT,
    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
});
let clockDigitMinHigh = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
    x: clockDigitMinHigh_xPos,
    y: clockDigitMinHigh_yPos,
    font_array: ["CLOCKWHITE_0.png", "CLOCKWHITE_1.png", "CLOCKWHITE_2.png", "CLOCKWHITE_3.png", "CLOCKWHITE_4.png", "CLOCKWHITE_5.png", "CLOCKWHITE_6.png", "CLOCKWHITE_7.png", "CLOCKWHITE_8.png", "CLOCKWHITE_9.png"],
    padding: false,
    h_space: 0,
    text: "0",
    align_h: hmUI.align.LEFT,
    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
});

function updateClock(){
    let clockHr = timeSensor.hour;
    let clockMin = timeSensor.minute;

    //Convert clock
    if (currHourFormat == 0) {
        clockHr = clockHr % 12 || 12;
    }

    //Add zeros if hr<10
    let clockHrTXT = clockHr.toString().padStart(2, "0");
    let clockMinsTXT = clockMin.toString().padStart(2, "0");

    //Set digits
    clockDigitHrHigh.setProperty(hmUI.prop.TEXT, clockHrTXT[0]);
    clockDigitHrLow.setProperty(hmUI.prop.TEXT, clockHrTXT[1]);
    clockDigitMinHigh.setProperty(hmUI.prop.TEXT, clockMinsTXT[0]);
    clockDigitMinLow.setProperty(hmUI.prop.TEXT, clockMinsTXT[1]);
}
updateClock();
            // end user_script_beforeShortcuts.js

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 10,
              y: 125,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                settingsMenu(true)
makeVibrate(2)
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 290,
              y: 35,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 80,
              y: 345,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_batteryManagerScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 340,
              y: 295,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 165,
              y: 136,
              w: 150,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 165,
              y: 250,
              w: 150,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

//Main menu
let prevColorbtn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 10,
    y: 49,
    w: 134,
    h: 382,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'settings/EDGEBTN_PREV_PRESSED.png',
    normal_src: 'settings/EDGEBTN_PREV_NORMAL.png',
    show_level: hmUI.show_level.ONLY_NORMAL,
    click_func: (button_widget) => {
    prevColor()
    makeVibrate(1)
    }, // end func
}); // end button

let nextColorbtn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 336,
    y: 49,
    w: 134,
    h: 382,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'settings/EDGEBTN_NEXT_PRESSED.png',
    normal_src: 'settings/EDGEBTN_NEXT_NORMAL.png',
    show_level: hmUI.show_level.ONLY_NORMAL,
    click_func: (button_widget) => {
    nextColor()
    makeVibrate(1)
    }, // end func
}); // end button

let Confirmbtn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 180,
    y: 364,
    w: 120,
    h: 90,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'settings/BTN_CONFIRM_PRESSED.png',
    normal_src: 'settings/BTN_CONFIRM_NORMAL.png',
    show_level: hmUI.show_level.ONLY_NORMAL,
    click_func: (button_widget) => {
    settingsMenu(false)
    makeVibrate(3)
    }, // end func
}); // end button

function prevColor(){
    colorIndex = colorIndex - 1;
    if (colorIndex < 1) colorIndex = colorsSet;
    updateWatchface();
}

function nextColor(){
    colorIndex = colorIndex + 1;
    if (colorIndex > colorsSet) colorIndex = 1;
    updateWatchface();
}

function updateWatchface(){
    //Set source for elements
    let currBG_SRC = "BG_" + colorIndex + ".png";
    hmFS.SysProSetInt('AEONMAX_bgIndex', colorIndex);
    let currHANDhr_SRC = "CLOCK_HAND_HRMIN_" + colorIndex + ".png";
    let currHANDmin_SRC = "CLOCK_HAND_HRMIN_" + colorIndex + ".png";
    let currHANDsec_SRC = "CLOCK_HAND_SEC_" + colorIndex + ".png";

    // Get current angles for hour and minute hands
    let currHANDhr_angle = normal_analog_clock_pro_hour_pointer_img.getProperty(hmUI.prop.ANGLE);
    let currHANDmin_angle = normal_analog_clock_pro_minute_pointer_img.getProperty(hmUI.prop.ANGLE);

    //Set background image
    normal_background_bg_img.setProperty(hmUI.prop.SRC, currBG_SRC);

    //Set analog clock hands
    normal_analog_clock_time_pointer_smooth_second.setProperty(hmUI.prop.MORE, {
        second_path: currHANDsec_SRC,
        second_centerX: 240,
        second_centerY: 240,
        second_posX: 142,
        second_posY: 212,
        fresh_frequency: 15,
        fresh_freqency: 15,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.MORE, {
        x: 0,
        y: 0,
        w: deviceInfo.width,
        h: deviceInfo.height,
        pos_x: 240 - 40,
        pos_y: 240 - 200,
        center_x: 240,
        center_y: 240,
        src: currHANDhr_SRC,
        angle: currHANDhr_angle,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });
    
    normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.MORE, {
        x: 0,
        y: 0,
        w: deviceInfo.width,
        h: deviceInfo.height,
        pos_x: 240 - 40,
        pos_y: 240 - 200,
        center_x: 240,
        center_y: 240,
        src: currHANDmin_SRC,
        angle: currHANDmin_angle,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });
};

let watchfaceButtons = [ Button_1, Button_2, Button_3, Button_4, Button_5, Button_6 ];
let settingMenuLayout = [ prevColorbtn, nextColorbtn, Confirmbtn ];

function settingsMenu(isVisible){
    watchfaceButtons.forEach(element => element.setProperty(hmUI.prop.VISIBLE, !isVisible));
    settingMenuLayout.forEach(element => element.setProperty(hmUI.prop.VISIBLE, isVisible));
};

settingsMenu(false);
idle_background_bg_img.setProperty(hmUI.prop.SRC, "BG_" + [hmFS.SysProGetInt('AEONMAX_bgIndex') ?? 1] + ".png");
            // end user_script_end.js

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              if (updateMinute){
                updateClock();
              }

              if (updateMinute) { // Hour Pointer
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*(minute + second/60)/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              
              console.log('full date str');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                let normal_DOW_Str = currWatchfaceLang.WEEKDAYS_SHORT[timeSensor.week-1];
                let fullDate_Str = normal_DOW_Str + " " + normal_dayStr;

                normal_dow_text_font.setProperty(hmUI.prop.TEXT, fullDate_Str );
              };
            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, true);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }

                console.log('pause_call.js');
                // start pause_call.js

settingsMenu(false)
                // end pause_call.js

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}